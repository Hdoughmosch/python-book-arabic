# الفصل العاشر: البرمجة كائنية التوجه (OOP)
# 10.4 Class Methods و Static Methods
############################################################

class DateUtil:
    def __init__(self, year, month, day):
        self.year = year
        self.month = month
        self.day = day

# ---

# استخدام
date1 = DateUtil(2024, 5, 15)
print(date1.format())          # 2024-05-15

# ---

date2 = DateUtil.from_string("2024-12-25")
print(date2.format())          # 2024-12-25

# ---

print(DateUtil.is_valid_date(2024, 13, 5))  # False
