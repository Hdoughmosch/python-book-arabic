# الفصل العاشر: البرمجة كائنية التوجه (OOP)
# 10.1 Classes و Objects
############################################################

# تعريف Class
class Student:
    # Constructor
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

# ---

# انشاء Object
student1 = Student("أحمد", 20, 85)
student2 = Student("محمد", 22, 55)

# ---

print(student1.introduce())   # أنا أحمد، عمري 20، درجتي 85
print(student1.is_passed())   # True
print(student2.is_passed())   # False
