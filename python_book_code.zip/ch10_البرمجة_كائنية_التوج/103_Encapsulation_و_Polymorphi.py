# الفصل العاشر: البرمجة كائنية التوجه (OOP)
# 10.3 Encapsulation و Polymorphism
############################################################

class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.__balance = balance  # private

# ---

account = BankAccount("أحمد", 1000)
print(account.balance)       # 1000 (عبر Getter)
account.balance = 2000       # عبر Setter
print(account.balance)       # 2000

# ---

# Polymorphism
class Animal:
    def speak(self):
        raise NotImplementedError

# ---

class Dog(Animal):
    def speak(self):
        return "نباح!"

# ---

class Cat(Animal):
    def speak(self):
        return "مواء!"

# ---

def animal_sound(animal):
    print(animal.speak())

# ---

dog = Dog()
cat = Cat()
animal_sound(dog)          # نباح!
animal_sound(cat)          # مواء!
