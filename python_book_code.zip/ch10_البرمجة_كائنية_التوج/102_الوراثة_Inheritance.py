# الفصل العاشر: البرمجة كائنية التوجه (OOP)
# 10.2 الوراثة (Inheritance)
############################################################

# Class اساسي
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

# ---

# Class مشتق
class Teacher(Person):
    def __init__(self, name, age, subject, salary):
        super().__init__(name, age)
        self.subject = subject
        self.salary = salary

# ---

teacher = Teacher("د. علي", 40, "Python", 5000)
print(teacher.greet())      # مرحباً، أنا د. علي وأنا أستاذ
print(teacher.teach())      # أنا أدرّس Python
