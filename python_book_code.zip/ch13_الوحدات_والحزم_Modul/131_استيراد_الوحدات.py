# الفصل الثالث عشر: الوحدات والحزم (Modules & Packages)
# 13.1 استيراد الوحدات
############################################################

# استيراد الوحدة كاملة
import math
print(math.sqrt(16))       # 4.0
print(math.pi)             # 3.141592653589793

# ---

# استيراد دالة محددة
from math import sqrt, pow
print(sqrt(25))            # 5.0
print(pow(2, 3))           # 8.0

# ---

# استيراد باسم مستعار
import random as rnd
print(rnd.randint(1, 10))

# ---

from datetime import datetime as dt
now = dt.now()
print(now)
