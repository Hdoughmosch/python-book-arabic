# الفصل الثالث عشر: الوحدات والحزم (Modules & Packages)
# 13.2 انشاء وحدة خاصة
############################################################

# ملف: calculator.py
"""وحدة الآلة الحاسبة"""

# ---

def add(a, b):
    """جمع رقمين"""
    return a + b

# ---

def subtract(a, b):
    """طرح رقمين"""
    return a - b

# ---

def multiply(a, b):
    """ضرب رقمين"""
    return a * b

# ---

def divide(a, b):
    """قسمة رقمين"""
    if b == 0:
        raise ValueError("لا يمكن القسمة على صفر")
    return a / b

# ---

# استخدام الوحدة
# import calculator
# print(calculator.add(5, 3))
