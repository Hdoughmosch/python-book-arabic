# الفصل الثالث عشر: الوحدات والحزم (Modules & Packages)
# 13.3 وحدة os و sys
############################################################

import os
import sys

# ---

# معلومات النظام
print(os.name)             # posix / nt
print(sys.platform)        # linux / win32 / darwin

# ---

# المسارات
print(os.getcwd())         # المجلد الحالي
print(os.listdir("."))   # محتويات المجلد

# ---

# انشاء/حذف مجلد
os.mkdir("test_folder")
os.rmdir("test_folder")

# ---

# مسار الملف
print(os.path.exists("file.txt"))
print(os.path.isfile("file.txt"))
print(os.path.isdir("folder"))

# ---

# دمج المسارات
path = os.path.join("folder", "subfolder", "file.txt")
print(path)
