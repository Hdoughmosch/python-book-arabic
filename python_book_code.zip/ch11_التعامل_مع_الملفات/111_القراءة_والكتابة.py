# الفصل الحادي عشر: التعامل مع الملفات
# 11.1 القراءة والكتابة
############################################################

# كتابة في ملف
with open("students.txt", "w", encoding="utf-8") as file:
    file.write("أحمد: 85\n")
    file.write("محمد: 92\n")
    file.write("علي: 78\n")

# ---

# قراءة الملف كاملاً
with open("students.txt", "r", encoding="utf-8") as file:
    content = file.read()
    print(content)

# ---

# قراءة سطر بسطر
with open("students.txt", "r", encoding="utf-8") as file:
    for line in file:
        print(line.strip())

# ---

# قراءة في قائمة
with open("students.txt", "r", encoding="utf-8") as file:
    lines = file.readlines()
    print(lines)
