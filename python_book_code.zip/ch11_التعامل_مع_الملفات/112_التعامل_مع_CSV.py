# الفصل الحادي عشر: التعامل مع الملفات
# 11.2 التعامل مع CSV
############################################################

import csv

# ---

# كتابة CSV
with open("data.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["الاسم", "العمر", "الدرجة"])
    writer.writerow(["أحمد", 20, 85])
    writer.writerow(["محمد", 22, 92])

# ---

# قراءة CSV
with open("data.csv", "r", encoding="utf-8") as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)

# ---

# قراءة CSV كقاموس
with open("data.csv", "r", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(f"{row['الاسم']}: {row['الدرجة']}")
