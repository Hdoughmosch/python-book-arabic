# الفصل الحادي عشر: التعامل مع الملفات
# 11.3 التعامل مع JSON
############################################################

import json

# ---

# بيانات Python
student = {
    "name": "أحمد",
    "age": 20,
    "courses": ["Python", "Math"],
    "active": True
}

# ---

# تحويل الى JSON
json_string = json.dumps(student, ensure_ascii=False, indent=2)
print(json_string)

# ---

# حفظ في ملف
with open("student.json", "w", encoding="utf-8") as file:
    json.dump(student, file, ensure_ascii=False, indent=2)

# ---

# قراءة JSON
with open("student.json", "r", encoding="utf-8") as file:
    loaded_student = json.load(file)
    print(loaded_student["name"])

# ---

# تحويل JSON الى Python
data = json.loads('{"x": 10, "y": 20}')
print(data["x"])           # 10
