# الفصل التاسع عشر: علم البيانات الاساسي
# 19.2 Pandas
############################################################

# يتطلب: pip install pandas
import pandas as pd

# ---

# انشاء DataFrame
data = {
    "الاسم": ["أحمد", "محمد", "علي", "سارة"],
    "العمر": [20, 22, 19, 21],
    "الدرجة": [85, 92, 78, 95]
}
df = pd.DataFrame(data)
print(df)

# ---

# معلومات اساسية
print(df.head(2))
print(df.describe())
print(df.info())

# ---

# الوصول للبيانات
print(df["الاسم"])
print(df.loc[0])           # الصف الاول
print(df.loc[df["الدرجة"] > 90])  # الدرجات > 90

# ---

# الترتيب
print(df.sort_values("الدرجة", ascending=False))

# ---

# احصائيات
print(df["الدرجة"].mean())
print(df["الدرجة"].max())
print(df.groupby("العمر")["الدرجة"].mean())

# ---

# قراءة/كتابة CSV
# df.to_csv("students.csv", index=False)
# df = pd.read_csv("students.csv")
