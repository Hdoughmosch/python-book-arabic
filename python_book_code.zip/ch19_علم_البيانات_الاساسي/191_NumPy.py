# الفصل التاسع عشر: علم البيانات الاساسي
# 19.1 NumPy
############################################################

# يتطلب: pip install numpy
import numpy as np

# ---

# انشاء مصفوفات
arr1 = np.array([1, 2, 3, 4, 5])
arr2 = np.array([[1, 2, 3], [4, 5, 6]])

# ---

# خصائص
print(arr2.shape)          # (2, 3)
print(arr2.dtype)          # int64
print(arr2.ndim)           # 2

# ---

# العمليات
print(arr1 + 10)           # [11 12 13 14 15]
print(arr1 * 2)            # [ 2  4  6  8 10]
print(np.sum(arr1))        # 15
print(np.mean(arr1))       # 3.0

# ---

# المصفوفات الخاصة
zeros = np.zeros((3, 3))
ones = np.ones((2, 4))
identity = np.eye(3)
random_arr = np.random.rand(3, 3)

# ---

# التقطيع
print(arr2[0, :])          # [1 2 3]
print(arr2[:, 1])          # [2 5]
