# الفصل السادس: الصفوف (Tuples) والمجموعات (Sets)
# 6.1 الصفوف (Tuples)
############################################################

# Tuple غير قابل للتعديل
coordinates = (10, 20)
print(coordinates[0])      # 10

# ---

# unpacking
x, y = coordinates
print(x, y)                # 10 20

# ---

# Tuple مع عنصر واحد (يجب الفاصلة)
single = (5,)
print(type(single))        # <class 'tuple'>

# ---

# دوال Tuple
numbers = (1, 2, 3, 2, 4, 2)
print(numbers.count(2))    # 3
print(numbers.index(3))    # 2

# ---

# تحويل بين List و Tuple
my_list = [1, 2, 3]
my_tuple = tuple(my_list)
back_to_list = list(my_tuple)
