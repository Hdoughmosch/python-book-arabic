# الفصل السادس: الصفوف (Tuples) والمجموعات (Sets)
# 6.2 المجموعات (Sets)
############################################################

# Set: مجموعة فريدة غير مرتبة
fruits = {"تفاح", "موز", "برتقال"}
print(fruits)

# ---

# اضافة عنصر
fruits.add("عنب")
print(fruits)

# ---

# ازالة عنصر
fruits.remove("موز")
print(fruits)

# ---

# عمليات المجموعات
a = {1, 2, 3, 4}
b = {3, 4, 5, 6}

# ---

# الاتحاد
print(a | b)               # {1, 2, 3, 4, 5, 6}
print(a.union(b))

# ---

# التقاطع
print(a & b)               # {3, 4}
print(a.intersection(b))

# ---

# الفرق
print(a - b)               # {1, 2}
print(a.difference(b))

# ---

# الفرق المتناظر
print(a ^ b)               # {1, 2, 5, 6}
print(a.symmetric_difference(b))

# ---

# ازالة التكرارات من قائمة
nums = [1, 2, 2, 3, 3, 3]
unique = list(set(nums))
print(unique)              # [1, 2, 3]
