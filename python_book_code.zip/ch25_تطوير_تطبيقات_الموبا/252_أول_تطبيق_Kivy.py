# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.2 أول تطبيق Kivy
############################################################

# ملف: main.py
from kivy.app import App
from kivy.uix.label import Label

# ---

class HelloApp(App):
    def build(self):
        return Label(text='مرحباً بك في Kivy!', font_size='30sp')

# ---

if __name__ == '__main__':
    HelloApp().run()
