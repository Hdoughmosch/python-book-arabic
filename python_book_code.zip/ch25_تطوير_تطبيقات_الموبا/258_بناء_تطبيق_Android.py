# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.8 بناء تطبيق Android
############################################################

# 1. تثبيت Buildozer
pip install buildozer

# ---

# 2. تهيئة المشروع
buildozer init

# ---

# 3. تعديل buildozer.spec
# title = تطبيقي
# package.name = myapp
# package.domain = org.example
# source.include_exts = py,png,jpg,kv,atlas
# requirements = python3,kivy
# orientation = portrait

# ---

# 4. بناء APK
buildozer android debug deploy run

# ---

# ملاحظة: يتطلب Linux. على Windows استخدم WSL أو Docker.
