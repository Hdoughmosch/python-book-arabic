# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.4 أنواع التخطيطات المتاحة
############################################################

from kivy.uix.boxlayout import BoxLayout      # ترتيب خطي
from kivy.uix.gridlayout import GridLayout    # شبكة
from kivy.uix.floatlayout import FloatLayout  # مواقع نسبية
from kivy.uix.anchorlayout import AnchorLayout # تثبيت في الزاوية
from kivy.uix.stacklayout import StackLayout   # تكديس

# ---

# مثال GridLayout
grid = GridLayout(cols=3, spacing=10, padding=10)
for i in range(9):
    grid.add_widget(Button(text=str(i+1)))
