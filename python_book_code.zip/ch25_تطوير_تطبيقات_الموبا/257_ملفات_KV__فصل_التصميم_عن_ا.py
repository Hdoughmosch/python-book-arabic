# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.7 ملفات KV - فصل التصميم عن المنطق
############################################################

# ملف: calculator.kv
<CalculatorWidget>:
    orientation: 'vertical'
    padding: 20
    spacing: 10

# ---

# ملف: main.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout

# ---

class CalculatorWidget(BoxLayout):
    def calculate(self, expression):
        try:
            result = eval(expression)
            self.ids.display.text = str(result)
        except:
            self.ids.display.text = 'خطأ'

# ---

class CalculatorApp(App):
    def build(self):
        return CalculatorWidget()

# ---

if __name__ == '__main__':
    CalculatorApp().run()
