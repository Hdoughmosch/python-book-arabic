# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.5 التعامل مع المدخلات
############################################################

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label

# ---

class InputApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

# ---

if __name__ == '__main__':
    InputApp().run()
