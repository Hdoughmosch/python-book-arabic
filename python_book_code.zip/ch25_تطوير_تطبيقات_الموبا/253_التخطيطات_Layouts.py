# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.3 التخطيطات (Layouts)
############################################################

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

# ---

class LayoutApp(App):
    def build(self):
        # BoxLayout: ترتيب عمودي أو أفقي
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

# ---

if __name__ == '__main__':
    LayoutApp().run()
