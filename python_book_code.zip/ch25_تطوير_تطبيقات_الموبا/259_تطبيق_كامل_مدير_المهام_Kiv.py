# الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
# 25.9 تطبيق كامل: مدير المهام (Kivy)
############################################################

# main.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.recycleview import RecycleView
from kivy.uix.popup import Popup
from kivy.properties import ListProperty
from kivy.storage.jsonstore import JsonStore

# ---

store = JsonStore('tasks.json')

# ---

class TaskList(RecycleView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.load_tasks()

# ---

class TodoApp(App):
    def build(self):
        return TodoWidget()

# ---

# todo.kv
<TodoWidget>:
    orientation: 'vertical'
    padding: 10
    spacing: 10

# ---

if __name__ == '__main__':
    TodoApp().run()
