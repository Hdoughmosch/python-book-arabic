# الفصل السابع عشر: قواعد البيانات (SQLite)
# 17.2 SQLite مع Context Manager
############################################################

import sqlite3

# ---

class Database:
    def __init__(self, db_name):
        self.db_name = db_name

# ---

# استخدام
with Database("school.db") as cursor:
    cursor.execute("SELECT * FROM students")
    for row in cursor.fetchall():
        print(f"{row['name']}: {row['grade']}")
