# الفصل السابع عشر: قواعد البيانات (SQLite)
# 17.1 SQLite الاساسي
############################################################

import sqlite3

# ---

# الاتصال بقاعدة البيانات
conn = sqlite3.connect("school.db")
cursor = conn.cursor()

# ---

# انشاء جدول
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        grade REAL
    )
""")

# ---

# ادراج بيانات
cursor.execute("INSERT INTO students (name, age, grade) VALUES (?, ?, ?)",
               ("أحمد", 20, 85.5))
cursor.execute("INSERT INTO students (name, age, grade) VALUES (?, ?, ?)",
               ("محمد", 22, 92.0))

# ---

# حفظ التغييرات
conn.commit()

# ---

# الاستعلام
cursor.execute("SELECT * FROM students")
students = cursor.fetchall()
for student in students:
    print(student)

# ---

# الاستعلام بشرط
cursor.execute("SELECT * FROM students WHERE grade > ?", (90,))
top_students = cursor.fetchall()
print(top_students)

# ---

# التحديث
cursor.execute("UPDATE students SET grade = ? WHERE name = ?", (95, "أحمد"))

# ---

# الحذف
cursor.execute("DELETE FROM students WHERE age < ?", (21,))

# ---

conn.commit()
conn.close()
