# الفصل الرابع عشر: البرمجة المتقدمة
# 14.2 Decorators متقدمة
############################################################

from functools import wraps
import time

# ---

# Decorator مع معاملات
def repeat(times):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

# ---

@repeat(3)
def greet(name):
    print(f"مرحباً {name}!")

# ---

greet("أحمد")

# ---

# Decorator لقياس الوقت
def timer(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"{func.__name__} استغرقت {elapsed:.4f} ثانية")
        return result
    return wrapper

# ---

@timer
def slow_function():
    time.sleep(1)
    return "تم!"

# ---

slow_function()
