# الفصل الرابع عشر: البرمجة المتقدمة
# 14.3 Context Managers
############################################################

# Context Manager باستخدام class
class FileManager:
    def __init__(self, filename, mode):
        self.filename = filename
        self.mode = mode
        self.file = None

# ---

# استخدام
with FileManager("test.txt", "w") as f:
    f.write("مرحباً!")

# ---

# Context Manager باستخدام decorator
from contextlib import contextmanager

# ---

@contextmanager
def managed_resource(name):
    print(f"تهيئة المورد: {name}")
    yield name
    print(f"تنظيف المورد: {name}")

# ---

with managed_resource("database") as res:
    print(f"استخدام: {res}")
