# الفصل الرابع عشر: البرمجة المتقدمة
# 14.1 Generators
############################################################

# Generator function
def countdown(n):
    while n > 0:
        yield n
        n -= 1

# ---

for num in countdown(5):
    print(num)             # 5, 4, 3, 2, 1

# ---

# Generator expression
squares = (x**2 for x in range(10))
print(next(squares))       # 0
print(next(squares))       # 1

# ---

# مثال عملي: قراءة ملف كبير
def read_large_file(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            yield line.strip()

# ---

# for line in read_large_file("huge_file.txt"):
#     process(line)
