# الفصل الثاني عشر: معالجة الأخطاء
# 12.1 try-except
############################################################

# معالجة خطأ بسيط
try:
    number = int(input("أدخل رقماً: "))
    print(f"ضعف الرقم: {number * 2}")
except ValueError:
    print("خطأ: يجب إدخال رقم صحيح!")

# ---

# معالجة انواع متعددة
try:
    x = int(input("المقسوم: "))
    y = int(input("المقسوم عليه: "))
    result = x / y
    print(f"الناتج: {result}")
except ValueError:
    print("يجب إدخال أرقام!")
except ZeroDivisionError:
    print("لا يمكن القسمة على صفر!")
except Exception as e:
    print(f"خطأ غير متوقع: {e}")
