# الفصل الثاني عشر: معالجة الأخطاء
# 12.2 try-except-else-finally
############################################################

def divide_numbers(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("خطأ: القسمة على صفر!")
        return None
    except TypeError:
        print("خطأ: يجب إدخال أرقام!")
        return None
    else:
        print("تمت العملية بنجاح!")
        return result
    finally:
        print("انتهى تنفيذ الدالة")

# ---

print(divide_numbers(10, 2))   # 5.0
print(divide_numbers(10, 0))   # None
