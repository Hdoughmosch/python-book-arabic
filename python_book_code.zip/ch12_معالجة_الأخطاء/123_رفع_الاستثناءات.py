# الفصل الثاني عشر: معالجة الأخطاء
# 12.3 رفع الاستثناءات
############################################################

def validate_age(age):
    if not isinstance(age, int):
        raise TypeError("العمر يجب أن يكون رقماً صحيحاً")
    if age < 0:
        raise ValueError("العمر لا يمكن أن يكون سالباً")
    if age > 150:
        raise ValueError("العمر غير واقعي")
    return True

# ---

try:
    validate_age(-5)
except ValueError as e:
    print(f"خطأ: {e}")

# ---

# Custom Exception
class InsufficientFundsError(Exception):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount
        super().__init__(f"رصيد غير كافٍ: الرصيد {balance}، المطلوب {amount}")

# ---

def withdraw(balance, amount):
    if amount > balance:
        raise InsufficientFundsError(balance, amount)
    return balance - amount

# ---

try:
    withdraw(100, 200)
except InsufficientFundsError as e:
    print(e)
