# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.11 بناء Chatbot تفاعلي
############################################################

import ollama

# ---

class OllamaChatbot:
    def __init__(self, model='llama3.2', system_prompt=None):
        self.model = model
        self.messages = []
        if system_prompt:
            self.messages.append({'role': 'system', 'content': system_prompt})

# ---

# استخدام
bot = OllamaChatbot(
    model='llama3.2',
    system_prompt='أنت مساعد مفيد وودود. ردودك بالعربية.'
)

# ---

print("🤖 Chatbot جاهز! اكتب 'خروج' للانهاء.")
while True:
    user_input = input("\n👤 أنت: ")
    if user_input.lower() in ['خروج', 'exit', 'quit']:
        break
