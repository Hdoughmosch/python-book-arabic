# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.9 استدعاء الأدوات (Function Calling / Tools)
############################################################

import ollama
import json

# ---

# تعريف أدوات (Functions)
tools = [
    {
        'type': 'function',
        'function': {
            'name': 'get_weather',
            'description': 'الحصول على حالة الطقس لمدينة معينة',
            'parameters': {
                'type': 'object',
                'properties': {
                    'city': {
                        'type': 'string',
                        'description': 'اسم المدينة'
                    },
                    'unit': {
                        'type': 'string',
                        'enum': ['celsius', 'fahrenheit'],
                        'description': 'وحدة القياس'
                    }
                },
                'required': ['city']
            }
        }
    },
    {
        'type': 'function',
        'function': {
            'name': 'calculate',
            'description': 'إجراء عملية حسابية',
            'parameters': {
                'type': 'object',
                'properties': {
                    'a': {'type': 'number'},
                    'b': {'type': 'number'},
                    'operation': {
                        'type': 'string',
                        'enum': ['add', 'subtract', 'multiply', 'divide']
                    }
                },
                'required': ['a', 'b', 'operation']
            }
        }
    }
]

# ---

# تنفيذ الأدوات
def get_weather(city, unit='celsius'):
    return f"الطقس في {city}: 25 درجة {unit} ☀️"

# ---

def calculate(a, b, operation):
    ops = {
        'add': a + b, 'subtract': a - b,
        'multiply': a * b, 'divide': a / b if b != 0 else 'خطأ'
    }
    return ops.get(operation, 'عملية غير معروفة')

# ---

# الدردشة مع أدوات
response = ollama.chat(
    model='llama3.2',
    messages=[{'role': 'user', 'content': 'ما حالة الطقس في القاهرة؟'}],
    tools=tools,
    stream=False  # يجب تعطيل الـ streaming مع الأدوات
)

# ---

# التحقق من طلب استدعاء أداة
if 'tool_calls' in response['message']:
    for tool_call in response['message']['tool_calls']:
        func_name = tool_call['function']['name']
        args = json.loads(tool_call['function']['arguments'])
