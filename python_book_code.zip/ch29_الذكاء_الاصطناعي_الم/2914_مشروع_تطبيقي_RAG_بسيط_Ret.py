# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.14 مشروع تطبيقي: RAG بسيط (Retrieval-Augmented Generation)
############################################################

import ollama
import numpy as np
import json
import os

# ---

class SimpleRAG:
    def __init__(self, embed_model='nomic-embed-text', chat_model='llama3.2'):
        self.embed_model = embed_model
        self.chat_model = chat_model
        self.documents = []
        self.embeddings = []

# ---

=== المعلومات ===
{context}

# ---

=== السؤال ===
{question}

# ---

=== الإجابة ==="""

# ---

# استخدام
rag = SimpleRAG()

# ---

# إضافة معلومات
knowledge = [
    "Python هي لغة برمجة عالية المستوى أنشأها Guido van Rossum عام 1991.",
    "Ollama يسمح بتشغيل نماذج اللغات الكبيرة محلياً على جهازك.",
    "FastAPI هو إطار عمل حديث لتطوير APIs باستخدام Python.",
    "SQLite هي قاعدة بيانات مدمجة خفيفة الوزن لا تحتاج خادم منفصل.",
    "Docker يسمح بتعبئة التطبيقات في حاويات لسهولة النشر."
]
rag.add_documents(knowledge)

# ---

# طرح سؤال
answer, sources = rag.ask("من أنشأ Python ومتى؟")
print("الإجابة:", answer)
print("\nالمصادر:")
for doc, score in sources:
    print(f"  [{score:.3f}] {doc}")
