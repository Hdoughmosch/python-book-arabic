# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.6 تخصيص معاملات النموذج
############################################################

import ollama

# ---

response = ollama.chat(
    model='llama3.2',
    messages=[{'role': 'user', 'content': 'اكتب قصة قصيرة'}],
    options={
        'temperature': 0.9,      # الإبداعية (0.0 - 1.0+)
        'top_p': 0.95,           # عينة Nucleus
        'top_k': 40,             # عينة Top-K
        'num_predict': 500,      # الحد الأقصى للتوكنات
        'seed': 42,              # للنتائج القابلة للتكرار
        'repeat_penalty': 1.1,   # عقوبة التكرار
    }
)
print(response['message']['content'])
