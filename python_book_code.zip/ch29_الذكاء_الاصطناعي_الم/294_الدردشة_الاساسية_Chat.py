# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.4 الدردشة الاساسية (Chat)
############################################################

import ollama

# ---

# دردشة بسيطة
response = ollama.chat(
    model='llama3.2',
    messages=[
        {'role': 'user', 'content': 'ما هي Python؟'}
    ]
)
print(response['message']['content'])

# ---

# مع سجل محادثة (Context/Memory)
messages = [
    {'role': 'system', 'content': 'أنت مساعد برمجي متخصص في Python.'},
    {'role': 'user', 'content': 'كيف أقرأ ملف نصي؟'},
]

# ---

response = ollama.chat(model='llama3.2', messages=messages)
assistant_reply = response['message']['content']
print(assistant_reply)

# ---

# إضافة رد المساعد للسجل والمتابعة
messages.append({'role': 'assistant', 'content': assistant_reply})
messages.append({'role': 'user', 'content': 'وما هي الطريقة الأفضل للملفات الكبيرة؟'})

# ---

response = ollama.chat(model='llama3.2', messages=messages)
print(response['message']['content'])
