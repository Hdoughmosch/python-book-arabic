# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.10 إنشاء نموذج مخصص (Custom Model)
############################################################

import ollama

# ---

# إنشاء نموذج بـ Modelfile
modelfile = '''
FROM llama3.2
SYSTEM """أنت مدرس Python متخصص. شرحك بسيط وعربي.
دائماً تعطي أمثلة عملية مع كل شرح."""
PARAMETER temperature 0.7
PARAMETER top_p 0.9
'''

# ---

ollama.create(model='python-teacher', modelfile=modelfile)

# ---

# استخدام النموذج المخصص
response = ollama.chat(
    model='python-teacher',
    messages=[{'role': 'user', 'content': 'اشرح الـ List Comprehension'}]
)
print(response['message']['content'])

# ---

# نسخ نموذج
ollama.copy('llama3.2', 'my-backup-model')

# ---

# حذف نموذج
ollama.delete('python-teacher')
