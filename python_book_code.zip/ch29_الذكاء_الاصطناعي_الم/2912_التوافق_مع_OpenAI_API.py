# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.12 التوافق مع OpenAI API
############################################################

# يمكن استخدام مكتبة OpenAI الرسمية مع Ollama
# pip install openai

# ---

from openai import OpenAI

# ---

client = OpenAI(
    base_url='http://localhost:11434/v1',
    api_key='ollama'  # مطلوب لكن لا يُستخدم
)

# ---

# Chat Completions
response = client.chat.completions.create(
    model='llama3.2',
    messages=[
        {'role': 'system', 'content': 'أنت مساعد مفيد.'},
        {'role': 'user', 'content': 'مرحباً!'}
    ],
    temperature=0.7
)
print(response.choices[0].message.content)

# ---

# Streaming
stream = client.chat.completions.create(
    model='llama3.2',
    messages=[{'role': 'user', 'content': 'حكي لي نكتة'}],
    stream=True
)
for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end='')

# ---

# Embeddings
embed_response = client.embeddings.create(
    model='nomic-embed-text',
    input='نص للتضمين'
)
print(len(embed_response.data[0].embedding))
