# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.1 ما هو Ollama?
############################################################

# macOS / Linux
curl -fsSL https://ollama.com/install.sh | sh

# ---

# Windows
# حمل المثبت من: https://ollama.com/download/windows

# ---

# التحقق من التثبيت
ollama --version

# ---

# تشغيل الخادم (يفتح تلقائياً على المنفذ 11434)
ollama serve
