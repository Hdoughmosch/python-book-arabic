# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.5 التوليد المتدفق (Streaming)
############################################################

import ollama

# ---

# Streaming: الرد يأتي حرفاً حرفاً
stream = ollama.chat(
    model='llama3.2',
    messages=[{'role': 'user', 'content': 'اكتب قصيدة عن البرمجة'}],
    stream=True
)

# ---

for chunk in stream:
    print(chunk['message']['content'], end='', flush=True)

# ---

# Streaming مع توليد (generate)
stream = ollama.generate(
    model='llama3.2',
    prompt='اشرح الذكاء الاصطناعي ببساطة',
    stream=True
)

# ---

for chunk in stream:
    print(chunk['response'], end='', flush=True)
