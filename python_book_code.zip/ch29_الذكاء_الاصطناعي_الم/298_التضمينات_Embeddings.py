# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.8 التضمينات (Embeddings)
############################################################

import ollama

# ---

# تضمين نص واحد
embed = ollama.embed(
    model='nomic-embed-text',
    input='Python هي لغة برمجة رائعة'
)
print(f"الأبعاد: {len(embed['embeddings'][0])}")
print(embed['embeddings'][0][:5])  # أول 5 قيم

# ---

# تضمين دفعة نصوص
texts = [
    'Python سهلة التعلم',
    'JavaScript للويب',
    'Rust للأداء العالي'
]
embeds = ollama.embed(model='nomic-embed-text', input=texts)
print(f"عدد التضمينات: {len(embeds['embeddings'])}")

# ---

# تطبيق: البحث الدلالي
def semantic_search(query, documents, model='nomic-embed-text'):
    import numpy as np

# ---

docs = [
    'Python تستخدم في علم البيانات والذكاء الاصطناعي',
    'JavaScript تستخدم في تطوير المواقع والتطبيقات',
    'Rust تستخدم في أنظمة التشغيل والبرمجيات عالية الأداء',
    'Python لها مكتبات مثل NumPy و Pandas و TensorFlow'
]

# ---

results = semantic_search('ما هي لغة الذكاء الاصطناعي؟', docs)
for doc, score in results:
    print(f"[{score:.3f}] {doc}")
