# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.3 سحب النماذج (Pull Models)
############################################################

import ollama

# ---

# سحب نموذج (أول مرة فقط)
ollama.pull('llama3.2')

# ---

# سحب نموذج تضمينات
ollama.pull('nomic-embed-text')

# ---

# سحب نموذج متعدد الوسائط
ollama.pull('llava')

# ---

# قائمة النماذج المتاحة محلياً
models = ollama.list()
for model in models['models']:
    print(f"{model['model']} - {model['size']}")

# ---

# معلومات نموذج محدد
info = ollama.show('llama3.2')
print(info)
