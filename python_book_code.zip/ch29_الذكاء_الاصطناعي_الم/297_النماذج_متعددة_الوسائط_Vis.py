# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.7 النماذج متعددة الوسائط (Vision / Multimodal)
############################################################

import ollama
import base64

# ---

# قراءة صورة وتحويلها لـ Base64
with open('image.jpg', 'rb') as f:
    image_base64 = base64.b64encode(f.read()).decode('utf-8')

# ---

# إرسال صورة مع السؤال
response = ollama.chat(
    model='llava',
    messages=[{
        'role': 'user',
        'content': 'ما الذي تراه في هذه الصورة؟',
        'images': [image_base64]
    }]
)
print(response['message']['content'])

# ---

# أو باستخدام مسار الملف مباشرة
response = ollama.chat(
    model='llava',
    messages=[{
        'role': 'user',
        'content': 'اشرح محتوى الصورة',
        'images': ['/path/to/photo.png']
    }]
)
