# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.13 مشروع تطبيقي: مساعد برمجي ذكي
############################################################

import ollama
import re

# ---

class CodeAssistant:
    def __init__(self):
        self.model = 'llama3.2'
        self.system = """أنت مساعد برمجي خبير في Python.
        قم بـ:
        1. شرح المفاهيم ببساطة
        2. إعطاء أمثلة عملية
        3. تحسين الكود المقدم
        4. اكتشاف الأخطاء وإصلاحها"""

# ---

```python
{code}
```
"""
        if error:
            prompt += f"\nالخطأ:\n{error}\n\nاشرح الخطأ وقدم الحل."
        else:
            prompt += "\nهل هناك أخطاء أو تحسينات ممكنة؟"

# ---

# استخدام
assistant = CodeAssistant()

# ---

print("=== شرح مفهوم ===")
print(assistant.explain("Decorators"))

# ---

print("\n=== تصحيح كود ===")
buggy_code = '''
def factorial(n):
    if n == 0:
        return 0
    return n * factorial(n - 1)
''', '
print(assistant.debug(buggy_code, "النتيجة غير صحيحة لـ factorial(5)"))

# ---

print("\n=== توليد كود ===")
print(assistant.generate("دالة لحساب متوسط درجات الطلاب من قاموس"))

# ---

print("\n=== مراجعة كود ===")
code_to_review = '''
def process_data(data):
    result = []
    for i in range(len(data)):
        if data[i] > 0:
            result.append(data[i] * 2)
    return result
''', '
print(assistant.review(code_to_review))
