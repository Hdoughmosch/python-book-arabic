# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.16 نصائح وأفضل الممارسات
############################################################

1. اختيار النموذج المناسب:

# ---

2. إدارة السياق (Context):

# ---

3. الأداء:

# ---

4. الأمان:

# ---

5. التعامل مع الأخطاء:

# ---

import ollama

# ---

try:
    response = ollama.chat(model='nonexistent-model', messages=[])
except ollama.ResponseError as e:
    print(f"خطأ: {e.error}")
    if e.status_code == 404:
        print("النموذج غير موجود. قم بسحبه أولاً:")
        ollama.pull('llama3.2')
except Exception as e:
    print(f"خطأ غير متوقع: {e}")

# ---

6. متغيرات البيئة:
