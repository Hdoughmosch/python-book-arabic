# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.15 إدارة النماذج والذاكرة
############################################################

import ollama

# ---

# النماذج المحملة حالياً (في الذاكرة)
running = ollama.ps()
print("النماذج النشطة:")
for model in running.get('models', []):
    print(f"  {model['name']} - {model['size']}")

# ---

# تحميل نموذج في الذاكرة (بدون دردشة)
ollama.chat(model='llama3.2', messages=[], keep_alive='10m')

# ---

# إفراغ نموذج من الذاكرة
ollama.chat(model='llama3.2', messages=[], keep_alive=0)

# ---

# أو عبر API مباشرة
import requests
requests.post('http://localhost:11434/api/generate',
              json={'model': 'llama3.2', 'keep_alive': 0})
