# الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
# 29.2 تثبيت مكتبة Python
############################################################

pip install ollama

# ---

# او عبر requirements.txt
# ollama>=0.3.0

# ---

# التحقق
import ollama
print(ollama.__version__)
