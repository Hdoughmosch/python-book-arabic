# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.6 انشاء مشروع BeeWare كامل
############################################################

# 1. انشاء مشروع جديد
briefcase new

# ---

# الاجابات:
# Formal Name: Task Manager
# App Name: taskmanager
# Bundle: com.example
# Project Name: Task Manager
# Description: تطبيق ادارة المهام
# Author: Your Name
# Email: your@email.com
# License: MIT
# GUI Framework: Toga

# ---

# 2. هيكل المشروع
taskmanager/
├── src/
│   └── taskmanager/
│       ├── __init__.py
│       ├── app.py          # الكود الرئيسي
│       └── resources/      # الصور والايقونات
├── tests/
├── pyproject.toml
└── README.rst

# ---

# 3. تطوير التطبيق
# src/taskmanager/app.py
import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW

# ---

class TaskManager(toga.App):
    def startup(self):
        self.tasks = []
        self.build_ui()

# ---

def main():
    return TaskManager()

# ---

# 4. تشغيل التطبيق
briefcase dev

# ---

# 5. بناء لمنصات مختلفة
# Windows
briefcase create windows
briefcase build windows
briefcase run windows
briefcase package windows

# ---

# macOS
briefcase create macOS
briefcase build macOS
briefcase run macOS
briefcase package macOS --sign

# ---

# Linux
briefcase create linux
briefcase build linux
briefcase run linux
briefcase package linux --format appimage

# ---

# Android
briefcase create android
briefcase build android
briefcase run android
briefcase package android

# ---

# iOS (يتطلب macOS و Xcode)
briefcase create iOS
briefcase build iOS
briefcase run iOS
briefcase package iOS

# ---

# Web (WASM)
briefcase create web
briefcase build web
briefcase run web
