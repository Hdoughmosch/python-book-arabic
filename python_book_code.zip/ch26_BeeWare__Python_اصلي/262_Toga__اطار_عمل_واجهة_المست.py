# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.2 Toga - اطار عمل واجهة المستخدم
############################################################

# تثبيت Toga
pip install toga

# ---

# اول تطبيق Toga
import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW

# ---

class HelloWorld(toga.App):
    def startup(self):
        # انشاء الصندوق الرئيسي
        main_box = toga.Box(style=Pack(direction=COLUMN, padding=20))

# ---

def main():
    return HelloWorld()

# ---

if __name__ == '__main__':
    main().main_loop()
