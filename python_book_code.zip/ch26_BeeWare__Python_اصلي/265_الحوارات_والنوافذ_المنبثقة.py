# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.5 الحوارات والنوافذ المنبثقة
############################################################

import toga

# ---

# Info Dialog
async def show_info(widget, app):
    await app.dialog(toga.InfoDialog(
        'عنوان',
        'هذه رسالة معلومات'
    ))

# ---

# Question Dialog
async def ask_question(widget, app):
    result = await app.dialog(toga.QuestionDialog(
        'تأكيد',
        'هل انت متأكد؟'
    ))
    if result:
        print('تم التأكيد')
    else:
        print('تم الالغاء')

# ---

# Error Dialog
async def show_error(widget, app):
    await app.dialog(toga.ErrorDialog(
        'خطأ',
        'حدث خطأ غير متوقع'
    ))

# ---

# File Open Dialog
async def open_file(widget, app):
    file_path = await app.dialog(toga.OpenFileDialog(
        'اختر ملف',
        file_types=['txt', 'py']
    ))
    if file_path:
        print(f'تم اختيار: {file_path}')

# ---

# File Save Dialog
async def save_file(widget, app):
    file_path = await app.dialog(toga.SaveFileDialog(
        'حفظ باسم',
        suggested_filename='document.txt'
    ))

# ---

# Folder Select Dialog
async def select_folder(widget, app):
    folder = await app.dialog(toga.SelectFolderDialog('اختر مجلد'))
