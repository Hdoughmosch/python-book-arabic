# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.3 عناصر واجهة Toga
############################################################

# عناصر متنوعة
import toga

# ---

# Label - نص
label = toga.Label('نص توضيحي')

# ---

# Button - زر
button = toga.Button('اضغط', on_press=handler)

# ---

# TextInput - حقل نصي
text_input = toga.TextInput(placeholder='اكتب هنا')

# ---

# PasswordInput - حقل كلمة مرور
password = toga.PasswordInput()

# ---

# NumberInput - حقل رقمي
number = toga.NumberInput(min_value=0, max_value=100)

# ---

# Selection - قائمة منسدلة
selection = toga.Selection(items=['احمر', 'اخضر', 'ازرق'])

# ---

# Switch - مفتاح تبديل
switch = toga.Switch('تفعيل')

# ---

# Slider - شريط تمرير
slider = toga.Slider(min=0, max=100, value=50)

# ---

# ProgressBar - شريط تقدم
progress = toga.ProgressBar(max=100, value=30)

# ---

# ImageView - صورة
image = toga.ImageView(image='path/to/image.png')

# ---

# WebView - متصفح
webview = toga.WebView(url='https://python.org')

# ---

# Table - جدول
table = toga.Table(
    headings=['الاسم', 'العمر'],
    data=[['احمد', 20], ['محمد', 22]]
)

# ---

# ScrollContainer - تمرير
scroll = toga.ScrollContainer(content=content_box)

# ---

# SplitContainer - تقسيم
split = toga.SplitContainer(content=[left_box, right_box])
