# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.4 التخطيطات في Toga
############################################################

from toga.style import Pack
from toga.style.pack import COLUMN, ROW

# ---

# Box رأسي
vbox = toga.Box(style=Pack(direction=COLUMN, padding=10))

# ---

# Box افقي
hbox = toga.Box(style=Pack(direction=ROW, padding=10))

# ---

# التحكم في الحجم
widget = toga.Button(
    'زر',
    style=Pack(
        flex=1,              # يملأ المساحة المتاحة
        padding=10,
        width=200,
        height=50
    )
)

# ---

# مثال تخطيط متقدم
class LayoutApp(toga.App):
    def startup(self):
        # Header
        header = toga.Box(style=Pack(direction=ROW, padding=10))
        header.add(toga.Label('التطبيق', style=Pack(flex=1, font_size=18)))
        header.add(toga.Button('⚙️'))
