# الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
# 26.7 اعدادات pyproject.toml
############################################################

[tool.briefcase]
project_name = "Task Manager"
bundle = "com.example"
version = "1.0.0"
url = "https://example.com/taskmanager"
license = "MIT license"

# ---

[tool.briefcase.app.taskmanager]
formal_name = "Task Manager"
description = "تطبيق ادارة المهام"
icon = "src/taskmanager/resources/taskmanager"
sources = [
    "src/taskmanager",
]
requires = [
    "toga>=0.4.0",
]

# ---

[tool.briefcase.app.taskmanager.macOS]
requires = [
    "toga-cocoa>=0.4.0",
]

# ---

[tool.briefcase.app.taskmanager.linux]
requires = [
    "toga-gtk>=0.4.0",
]

# ---

[tool.briefcase.app.taskmanager.windows]
requires = [
    "toga-winforms>=0.4.0",
]

# ---

[tool.briefcase.app.taskmanager.iOS]
requires = [
    "toga-iOS>=0.4.0",
]

# ---

[tool.briefcase.app.taskmanager.android]
requires = [
    "toga-android>=0.4.0",
]
