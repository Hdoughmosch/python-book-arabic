# الفصل الخامس: القوائم (Lists)
# 5.3 دوال وطرق القوائم
############################################################

# اضافة عنصر
nums = [1, 2, 3]
nums.append(4)
print(nums)                # [1, 2, 3, 4]

# ---

# ادراج في موقع محدد
nums.insert(1, 99)
print(nums)                # [1, 99, 2, 3, 4]

# ---

# اضافة قائمة اخرى
more = [5, 6]
nums.extend(more)
print(nums)                # [1, 99, 2, 3, 4, 5, 6]

# ---

# ازالة عنصر
nums.remove(99)
print(nums)                # [1, 2, 3, 4, 5, 6]

# ---

# ازالة بالفهرس
popped = nums.pop()
print(popped)              # 6
print(nums)                # [1, 2, 3, 4, 5]

# ---

# البحث
print(nums.index(3))       # 2

# ---

# الترتيب
nums.sort(reverse=True)
print(nums)                # [5, 4, 3, 2, 1]

# ---

# عدد التكرارات
print(nums.count(3))       # 1

# ---

# نسخ القائمة
nums_copy = nums.copy()
print(nums_copy)           # [5, 4, 3, 2, 1]
