# الفصل الخامس: القوائم (Lists)
# 5.4 فهم القوائم (List Comprehension)
############################################################

# القائمة التقليدية
squares = []
for x in range(10):
    squares.append(x ** 2)
print(squares)             # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# ---

# باستخدام List Comprehension
squares = [x**2 for x in range(10)]
print(squares)

# ---

# مع شرط
even_squares = [x**2 for x in range(10) if x % 2 == 0]
print(even_squares)        # [0, 4, 16, 36, 64]

# ---

# مع if-else
labels = ["زوجي" if x % 2 == 0 else "فردي" for x in range(5)]
print(labels)              # ['زوجي', 'فردي', 'زوجي', 'فردي', 'زوجي']
