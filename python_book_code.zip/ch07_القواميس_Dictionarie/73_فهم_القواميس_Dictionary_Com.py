# الفصل السابع: القواميس (Dictionaries)
# 7.3 فهم القواميس (Dictionary Comprehension)
############################################################

# انشاء قاموس من قائمة
names = ["أحمد", "محمد", "علي"]
name_lengths = {name: len(name) for name in names}
print(name_lengths)        # {'أحمد': 4, 'محمد': 4, 'علي': 3}

# ---

# مع شرط
squares = {x: x**2 for x in range(10) if x % 2 == 0}
print(squares)             # {0: 0, 2: 4, 4: 16, 6: 36, 8: 64}
