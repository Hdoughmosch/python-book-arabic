# الفصل السابع: القواميس (Dictionaries)
# 7.1 انشاء والوصول للقواميس
############################################################

# انشاء قاموس
student = {
    "name": "محمد",
    "age": 20,
    "grade": 85.5,
    "courses": ["Python", "Math"]
}

# ---

# الوصول للقيم
print(student["name"])     # محمد
print(student.get("age"))  # 20

# ---

# الوصول بقيمة افتراضية
print(student.get("phone", "غير متوفر"))  # غير متوفر

# ---

# تعديل قيمة
student["age"] = 21
print(student["age"])      # 21

# ---

# اضافة مفتاح جديد
student["phone"] = "0123456789"
print(student)
