# الفصل السابع: القواميس (Dictionaries)
# 7.2 طرق القواميس
############################################################

student = {"name": "علي", "age": 22, "grade": 90}

# ---

# المفاتيح
print(student.keys())      # dict_keys(['name', 'age', 'grade'])

# ---

# القيم
print(student.values())    # dict_values(['علي', 22, 90])

# ---

# الازواج
print(student.items())     # dict_items([('name', 'علي'), ...])

# ---

# التكرار على القاموس
for key, value in student.items():
    print(f"{key}: {value}")

# ---

# دمج قواميس
extra = {"city": "القاهرة", "phone": "0123"}
student.update(extra)
print(student)

# ---

# ازالة مفتاح
removed = student.pop("phone")
print(removed)             # 0123

# ---

# افراغ القاموس
student.clear()
print(student)             # {}
