# الفصل العشرون: مشاريع تطبيقية
# 20.3 تحميل الملفات مع شريط تقدم
############################################################

import requests
from tqdm import tqdm  # pip install tqdm

# ---

def download_file(url, filename=None):
    if filename is None:
        filename = url.split("/")[-1]

# ---

# استخدام
# download_file("https://example.com/file.zip")
