# الفصل العشرون: مشاريع تطبيقية
# 20.2 آلة حاسبة متقدمة
############################################################

import math

# ---

class AdvancedCalculator:
    def __init__(self):
        self.history = []

# ---

# استخدام
calc = AdvancedCalculator()
print(calc.add(10, 5))
print(calc.power(2, 10))
print(calc.factorial(5))
calc.show_history()
