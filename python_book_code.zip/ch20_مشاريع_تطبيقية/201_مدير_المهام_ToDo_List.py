# الفصل العشرون: مشاريع تطبيقية
# 20.1 مدير المهام (To-Do List)
############################################################

import json
import os
from datetime import datetime

# ---

class TodoManager:
    def __init__(self, filename="tasks.json"):
        self.filename = filename
        self.tasks = self.load_tasks()

# ---

# استخدام
todo = TodoManager()
todo.add_task("تعلم Python", "عالية")
todo.add_task("قراءة كتاب", "منخفضة")
todo.list_tasks()
