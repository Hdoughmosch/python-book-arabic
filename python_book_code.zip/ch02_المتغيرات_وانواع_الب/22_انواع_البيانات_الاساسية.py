# الفصل الثاني: المتغيرات وانواع البيانات
# 2.2 انواع البيانات الاساسية
############################################################

# String - النصوص
course = "برمجة Python"
print(type(course))        # <class 'str'>

# ---

# Integer - الاعداد الصحيحة
students_count = 30
print(type(students_count)) # <class 'int'>

# ---

# Float - الاعداد العشرية
price = 19.99
print(type(price))         # <class 'float'>

# ---

# Boolean - القيم المنطقية
is_active = False
print(type(is_active))     # <class 'bool'>

# ---

# None - القيمة الفارغة
result = None
print(type(result))        # <class 'NoneType'>
