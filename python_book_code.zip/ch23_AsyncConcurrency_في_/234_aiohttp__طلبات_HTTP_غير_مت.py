# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.4 aiohttp - طلبات HTTP غير متزامنة
############################################################

# pip install aiohttp
import aiohttp
import asyncio

# ---

async def fetch_url(session, url):
    async with session.get(url) as response:
        return await response.text()

# ---

async def fetch_multiple(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_url(session, url) for url in urls]
        results = await asyncio.gather(*tasks)
        return results

# ---

# مثال عملي
async def main():
    urls = [
        'https://api.github.com',
        'https://httpbin.org/get',
        'https://jsonplaceholder.typicode.com/posts/1'
    ]
    results = await fetch_multiple(urls)
    for url, result in zip(urls, results):
        print(f"{url}: {len(result)} بايت")

# ---

asyncio.run(main())
