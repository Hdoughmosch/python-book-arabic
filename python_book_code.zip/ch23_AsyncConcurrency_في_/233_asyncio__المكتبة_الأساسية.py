# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.3 asyncio - المكتبة الأساسية
############################################################

import asyncio

# ---

# async/await الأساسي
async def say_hello():
    print("مرحباً...")
    await asyncio.sleep(1)
    print("...وداعاً!")

# ---

# تشغيل الدالة
asyncio.run(say_hello())

# ---

# إنشاء Task
async def main():
    task1 = asyncio.create_task(say_hello())
    task2 = asyncio.create_task(say_hello())
    await task1
    await task2

# ---

asyncio.run(main())

# ---

# asyncio.gather - تنفيذ متعدد
async def fetch_all():
    urls = ['api1.com', 'api2.com', 'api3.com']
    tasks = [fetch_url(url) for url in urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return results

# ---

# asyncio.wait - انتظار أول مهمة تكتمل
async def race():
    task1 = asyncio.create_task(slow_operation())
    task2 = asyncio.create_task(fast_operation())
    done, pending = await asyncio.wait(
        [task1, task2],
        return_when=asyncio.FIRST_COMPLETED
    )
    for task in pending:
        task.cancel()

# ---

# asyncio.as_completed - معالجة النتائج فوراً
async def process_as_ready():
    tasks = [fetch_url(url) for url in urls]
    for completed in asyncio.as_completed(tasks):
        result = await completed
        print(f"تم: {result}")
