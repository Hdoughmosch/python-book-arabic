# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.10 WebSocket غير متزامن
############################################################

from fastapi import FastAPI, WebSocket

# ---

app = FastAPI()

# ---

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        await websocket.send_text(f"رد: {data}")
