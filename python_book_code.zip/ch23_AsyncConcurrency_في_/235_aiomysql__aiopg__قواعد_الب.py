# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.5 aiomysql / aiopg - قواعد البيانات غير المتزامنة
############################################################

# pip install aiomysql
import aiomysql

# ---

async def get_users():
    conn = await aiomysql.connect(
        host='localhost', user='root',
        password='pass', db='mydb'
    )
    async with conn.cursor() as cur:
        await cur.execute("SELECT * FROM users")
        result = await cur.fetchall()
        return result

# ---

# aiopg for PostgreSQL
# pip install aiopg
import aiopg

# ---

async def get_data():
    async with aiopg.create_pool('dbname=test user=postgres') as pool:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT * FROM data")
                return await cur.fetchall()
