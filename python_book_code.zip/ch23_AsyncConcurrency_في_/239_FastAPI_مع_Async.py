# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.9 FastAPI مع Async
############################################################

from fastapi import FastAPI
import asyncio

# ---

app = FastAPI()

# ---

@app.get("/")
async def root():
    await asyncio.sleep(0.1)  # محاكاة عملية
    return {"message": "مرحباً"}

# ---

@app.get("/items/{item_id}")
async def read_item(item_id: int):
    # عملية I/O غير متزامنة
    data = await fetch_from_database(item_id)
    return {"item": data}

# ---

# تشغيل: uvicorn main:app --reload
