# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.2 المفاهيم الأساسية
############################################################

# المقارنة بين Sync و Async
import time

# ---

# === الطريقة المتزامنة (Blocking) ===
def fetch_data_sync(url):
    time.sleep(2)  # محاكاة طلب شبكة
    return f"بيانات من {url}"

# ---

def main_sync():
    urls = ['site1.com', 'site2.com', 'site3.com']
    results = []
    for url in urls:
        results.append(fetch_data_sync(url))
    return results

# ---

# الوقت: 3 × 2 = 6 ثواني

# ---

# === الطريقة غير المتزامنة (Non-blocking) ===
import asyncio

# ---

async def fetch_data_async(url):
    await asyncio.sleep(2)  # محاكاة طلب شبكة
    return f"بيانات من {url}"

# ---

async def main_async():
    urls = ['site1.com', 'site2.com', 'site3.com']
    tasks = [fetch_data_async(url) for url in urls]
    results = await asyncio.gather(*tasks)
    return results

# ---

# الوقت: ~2 ثانية فقط (تنفيذ متوازي)
