# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.6 Threading - التعددية بالخيوط
############################################################

import threading
import time

# ---

# خيط بسيط
def worker(name):
    print(f"خيط {name} يبدأ")
    time.sleep(2)
    print(f"خيط {name} ينتهي")

# ---

thread = threading.Thread(target=worker, args=("A",))
thread.start()
thread.join()  # انتظار الانتهاء

# ---

# ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor

# ---

def fetch_url(url):
    import requests
    return requests.get(url).text

# ---

urls = ['https://api.github.com'] * 10
with ThreadPoolExecutor(max_workers=5) as executor:
    results = list(executor.map(fetch_url, urls))

# ---

# Lock - للوصول الآمن للبيانات المشتركة
counter = 0
lock = threading.Lock()

# ---

def increment():
    global counter
    with lock:
        temp = counter
        time.sleep(0.001)
        counter = temp + 1
