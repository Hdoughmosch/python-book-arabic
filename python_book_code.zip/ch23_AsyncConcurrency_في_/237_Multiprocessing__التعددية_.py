# الفصل الثالث والعشرون: Async/Concurrency في Python
# 23.7 Multiprocessing - التعددية بالعمليات
############################################################

from multiprocessing import Pool, Process
import os

# ---

# Process بسيط
def worker(num):
    print(f"العملية {os.getpid()} تعالج {num}")
    return num * num

# ---

# Pool - مجموعة عمليات
with Pool(processes=4) as pool:
    results = pool.map(worker, range(10))
    print(results)  # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# ---

# Process منفصل
p = Process(target=worker, args=(5,))
p.start()
p.join()

# ---

# Queue - للتواصل بين العمليات
from multiprocessing import Queue

# ---

def producer(queue):
    for i in range(5):
        queue.put(i)

# ---

def consumer(queue):
    while True:
        item = queue.get()
        if item is None:
            break
        print(f"استلم: {item}")

# ---

q = Queue()
p1 = Process(target=producer, args=(q,))
p2 = Process(target=consumer, args=(q,))
p1.start()
p2.start()
p1.join()
q.put(None)
p2.join()
