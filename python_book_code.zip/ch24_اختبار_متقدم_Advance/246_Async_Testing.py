# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.6 Async Testing
############################################################

import pytest
import asyncio

# ---

@pytest.mark.asyncio
async def test_async_fetch():
    result = await fetch_data("https://api.example.com")
    assert result is not None

# ---

@pytest.mark.asyncio
async def test_async_timeout():
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(
            slow_operation(), timeout=0.1
        )
