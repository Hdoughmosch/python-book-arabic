# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.5 Mocking - المحاكاة
############################################################

from unittest.mock import Mock, patch, MagicMock
import pytest

# ---

# Mock بسيط
def test_with_mock():
    mock_db = Mock()
    mock_db.get_user.return_value = {"name": "أحمد"}
    result = mock_db.get_user(1)
    assert result["name"] == "أحمد"

# ---

# Patch - استبدال مؤقت
@patch('requests.get')
def test_fetch(mock_get):
    mock_get.return_value.json.return_value = {"data": "test"}
    result = fetch_api()
    assert result == {"data": "test"}

# ---

# Patch كسياق
def test_with_context():
    with patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        assert check_file("test.txt") is True

# ---

# Mock للوقت
@patch('time.time')
def test_timestamp(mock_time):
    mock_time.return_value = 1234567890
    assert get_timestamp() == 1234567890
