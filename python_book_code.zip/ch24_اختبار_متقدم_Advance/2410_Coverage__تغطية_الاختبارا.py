# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.10 Coverage - تغطية الاختبارات
############################################################

# pytest-cov
pytest --cov=src --cov-report=html --cov-report=term-missing

# ---

# .coveragerc
[run]
source = src
omit = */tests/*, */venv/*

# ---

[report]
fail_under = 80  # يفشل إذا كانت التغطية أقل من 80%
show_missing = True
