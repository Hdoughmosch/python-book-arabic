# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.4 Parametrization - الاختبار المعاملي
############################################################

import pytest

# ---

@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 3),
    (5, 5, 10),
    (-1, 1, 0),
    (0, 0, 0),
])
def test_add(a, b, expected):
    assert add(a, b) == expected

# ---

@pytest.mark.parametrize("url,status", [
    ("https://google.com", 200),
    ("https://github.com", 200),
    ("https://notexist.com", None),
])
def test_urls(url, status):
    result = fetch_url(url)
    assert result == status
