# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.2 pytest - الإعداد والأساسيات
############################################################

# pip install pytest pytest-cov pytest-asyncio

# ---

# هيكل المشروع
myproject/
├── src/
│   └── calculator.py
├── tests/
│   ├── __init__.py
│   ├── test_calculator.py
│   └── conftest.py
└── pytest.ini

# ---

# pytest.ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = -v --tb=short --strict-markers
