# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.3 Fixtures - التجهيزات المتقدمة
############################################################

# conftest.py - ملفات مشتركة
import pytest
import tempfile
import os

# ---

@pytest.fixture
def temp_file():
    """ملف مؤقت"""
    fd, path = tempfile.mkstemp()
    yield path
    os.close(fd)
    os.unlink(path)

# ---

@pytest.fixture(scope="module")
def database():
    """قاعدة بيانات لكل الوحدة"""
    db = create_test_db()
    yield db
    db.cleanup()

# ---

@pytest.fixture(scope="session")
def app_config():
    """إعدادات للجلسة كاملة"""
    return {"debug": True, "database": "test"}

# ---

@pytest.fixture(params=["mysql", "postgresql", "sqlite"])
def db_engine(request):
    """اختبار على عدة محركات"""
    return create_engine(request.param)

# ---

# استخدام Fixtures
def test_with_temp(temp_file):
    with open(temp_file, 'w') as f:
        f.write("test")
    assert os.path.exists(temp_file)
