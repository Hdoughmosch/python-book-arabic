# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.7 Integration Testing
############################################################

import pytest
from fastapi.testclient import TestClient

# ---

@pytest.fixture
def client():
    from main import app
    return TestClient(app)

# ---

def test_api_integration(client):
    response = client.get("/api/users")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

# ---

def test_api_create_user(client):
    response = client.post("/api/users", json={
        "name": "أحمد",
        "email": "ahmed@example.com"
    })
    assert response.status_code == 201
    assert response.json()["name"] == "أحمد"
