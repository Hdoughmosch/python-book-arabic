# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.11 TDD - التطوير الموجه بالاختبارات
############################################################

# الخطوات:
# 1. اكتب اختبار يفشل (Red)
# 2. اكتب أقل كود يجعله ينجح (Green)
# 3. حسّن الكود (Refactor)

# ---

# مثال TDD لدالة factorial

# ---

# === المرحلة 1: الاختبار ===
def test_factorial():
    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(5) == 120

# ---

# === المرحلة 2: التنفيذ ===
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

# ---

# === المرحلة 3: التحسين ===
def factorial(n):
    """حساب العاملية مع التحقق من الصحة."""
    if not isinstance(n, int) or n < 0:
        raise ValueError("n يجب أن يكون عدداً صحيحاً موجباً")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
