# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.8 Property-Based Testing (Hypothesis)
############################################################

# pip install hypothesis
from hypothesis import given, strategies as st

# ---

@given(st.integers(), st.integers())
def test_add_commutative(a, b):
    assert add(a, b) == add(b, a)

# ---

@given(st.lists(st.integers()))
def test_sort_idempotent(lst):
    assert sorted(sorted(lst)) == sorted(lst)

# ---

@given(st.text())
def test_reverse_twice(s):
    assert reverse(reverse(s)) == s
