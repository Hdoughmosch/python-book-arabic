# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.12 CI/CD مع GitHub Actions
############################################################

# .github/workflows/test.yml
name: Tests

# ---

on: [push, pull_request]

# ---

jobs:
