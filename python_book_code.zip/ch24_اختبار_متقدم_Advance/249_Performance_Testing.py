# الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
# 24.9 Performance Testing
############################################################

import pytest
import time

# ---

@pytest.mark.benchmark
def test_algorithm_performance():
    start = time.time()
    result = heavy_algorithm()
    elapsed = time.time() - start
    assert elapsed < 1.0  # يجب أن يكتمل في أقل من ثانية

# ---

# pytest-benchmark
# pip install pytest-benchmark

# ---

def test_sort_benchmark(benchmark):
    data = list(range(1000, 0, -1))
    result = benchmark(sorted, data)
    assert result == list(range(1, 1001))
