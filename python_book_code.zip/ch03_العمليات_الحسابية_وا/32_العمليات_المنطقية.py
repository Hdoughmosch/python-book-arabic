# الفصل الثالث: العمليات الحسابية والمنطقية
# 3.2 العمليات المنطقية
############################################################

x = 10
y = 20

# ---

# اكبر من
print(x > y)               # False

# ---

# اصغر من
print(x < y)               # True

# ---

# يساوي
print(x == 10)             # True

# ---

# لا يساوي
print(x != 10)             # False

# ---

# اكبر من او يساوي
print(x >= 10)             # True

# ---

# اصغر من او يساوي
print(x <= 5)              # False

# ---

# العمليات المنطقية
print(True and False)      # False
print(True or False)       # True
print(not True)            # False
