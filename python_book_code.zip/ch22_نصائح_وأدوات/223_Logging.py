# الفصل الثاني والعشرون: نصائح وأدوات
# 22.3 Logging
############################################################

import logging

# ---

# الإعداد
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("app.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)

# ---

logger = logging.getLogger(__name__)

# ---

# الاستخدام
logger.debug("رسالة تصحيح")
logger.info("عملية ناجحة")
logger.warning("تحذير")
logger.error("حدث خطأ")
logger.critical("خطأ فادح!")
