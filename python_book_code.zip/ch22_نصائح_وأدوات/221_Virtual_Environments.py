# الفصل الثاني والعشرون: نصائح وأدوات
# 22.1 Virtual Environments
############################################################

# انشاء بيئة افتراضية
python -m venv myenv

# ---

# تفعيل (Windows)
myenv\Scripts\activate

# ---

# تفعيل (Linux/Mac)
source myenv/bin/activate

# ---

# الغاء التفعيل
deactivate

# ---

# حفظ المتطلبات
pip freeze > requirements.txt

# ---

# تثبيت المتطلبات
pip install -r requirements.txt
