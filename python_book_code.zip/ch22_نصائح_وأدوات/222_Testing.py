# الفصل الثاني والعشرون: نصائح وأدوات
# 22.2 Testing
############################################################

# يتطلب: pip install pytest
import pytest

# ---

def add(a, b):
    return a + b

# ---

def divide(a, b):
    if b == 0:
        raise ValueError("لا يمكن القسمة على صفر")
    return a / b

# ---

# اختبارات
def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0

# ---

def test_divide():
    assert divide(10, 2) == 5
    with pytest.raises(ValueError):
        divide(10, 0)

# ---

# التشغيل: pytest test_file.py -v
