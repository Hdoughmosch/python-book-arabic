# الفصل الخامس عشر: مكتبات Python القياسية
# 15.3 itertools
############################################################

import itertools

# ---

# توليد جميع التوائم
colors = ["أحمر", "أخضر", "أزرق"]
sizes = ["S", "M", "L"]
for combo in itertools.product(colors, sizes):
    print(combo)

# ---

# التباديل
for perm in itertools.permutations([1, 2, 3], 2):
    print(perm)

# ---

# التوافيق
for comb in itertools.combinations([1, 2, 3, 4], 2):
    print(comb)

# ---

# تجميع
data = [("أ", 1), ("ب", 2), ("أ", 3)]
for key, group in itertools.groupby(data, lambda x: x[0]):
    print(key, list(group))
