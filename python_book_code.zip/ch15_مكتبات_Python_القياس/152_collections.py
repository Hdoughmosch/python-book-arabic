# الفصل الخامس عشر: مكتبات Python القياسية
# 15.2 collections
############################################################

from collections import Counter, defaultdict, namedtuple

# ---

# Counter
words = ["تفاح", "موز", "تفاح", "برتقال", "تفاح", "موز"]
word_count = Counter(words)
print(word_count)          # Counter({'تفاح': 3, 'موز': 2, 'برتقال': 1})
print(word_count.most_common(2))

# ---

# defaultdict
grouped = defaultdict(list)
for word in words:
    grouped[len(word)].append(word)
print(dict(grouped))

# ---

# namedtuple
Point = namedtuple("Point", ["x", "y"])
p = Point(10, 20)
print(p.x, p.y)            # 10 20
