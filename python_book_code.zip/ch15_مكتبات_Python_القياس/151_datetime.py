# الفصل الخامس عشر: مكتبات Python القياسية
# 15.1 datetime
############################################################

from datetime import datetime, date, timedelta

# ---

# التاريخ والوقت الحالي
now = datetime.now()
print(now)

# ---

# انشاء تاريخ محدد
birth_date = date(2000, 5, 15)
print(birth_date)

# ---

# الفرق بين تاريخين
age = date.today() - birth_date
print(f"العمر بالايام: {age.days}")

# ---

# اضافة/طرح فترات
future = now + timedelta(days=30)
print(future)

# ---

# التنسيق
formatted = now.strftime("%Y-%m-%d %H:%M:%S")
print(formatted)

# ---

# تحليل النص
parsed = datetime.strptime("2024-05-15", "%Y-%m-%d")
print(parsed)
