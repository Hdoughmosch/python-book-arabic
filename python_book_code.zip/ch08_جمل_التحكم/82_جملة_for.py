# الفصل الثامن: جمل التحكم
# 8.2 جملة for
############################################################

# التكرار على قائمة
fruits = ["تفاح", "موز", "برتقال"]
for fruit in fruits:
    print(fruit)

# ---

# التكرار مع range()
for i in range(5):
    print(i)               # 0, 1, 2, 3, 4

# ---

# range(start, stop, step)
for i in range(10, 0, -2):
    print(i)               # 10, 8, 6, 4, 2

# ---

# التكرار على نص
for char in "Python":
    print(char)

# ---

# التكرار على قاموس
student = {"name": "أحمد", "age": 20}
for key, value in student.items():
    print(f"{key} = {value}")

# ---

# enumerate() للحصول على الفهرس
for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")

# ---

# zip() للتكرار على قوائم متعددة
names = ["أحمد", "محمد"]
scores = [85, 90]
for name, score in zip(names, scores):
    print(f"{name}: {score}")
