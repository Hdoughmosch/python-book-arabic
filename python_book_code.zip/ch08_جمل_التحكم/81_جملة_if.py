# الفصل الثامن: جمل التحكم
# 8.1 جملة if
############################################################

age = 18

# ---

if age < 13:
    print("طفل")
elif age < 20:
    print("مراهق")         # ✓ سيطبع هذا
elif age < 60:
    print("بالغ")
else:
    print("كبير السن")

# ---

# if مختصرة
status = "بالغ" if age >= 18 else "قاصر"
print(status)              # بالغ

# ---

# if متداخلة
score = 85
if score >= 60:
    if score >= 90:
        print("ممتاز")
    elif score >= 80:
        print("جيد جداً")  # ✓
    else:
        print("جيد")
else:
    print("راسب")
