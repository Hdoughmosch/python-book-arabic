# الفصل الثامن: جمل التحكم
# 8.3 جملة while
############################################################

# while اساسية
count = 0
while count < 5:
    print(count)
    count += 1

# ---

# while مع break
while True:
    user_input = input("أدخل 'خروج' للانهاء: ")
    if user_input == "خروج":
        break

# ---

# while مع continue
num = 0
while num < 10:
    num += 1
    if num % 2 == 0:
        continue
    print(num)             # يطبع الاعداد الفردية فقط

# ---

# else مع while
i = 0
while i < 3:
    print(i)
    i += 1
else:
    print("انتهى التكرار بنجاح")
