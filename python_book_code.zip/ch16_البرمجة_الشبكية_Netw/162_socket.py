# الفصل السادس عشر: البرمجة الشبكية (Networking)
# 16.2 socket
############################################################

import socket

# ---

# Client بسيط
def simple_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("example.com", 80))
    request = "GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"
    client.send(request.encode())
    response = client.recv(4096)
    print(response.decode())
    client.close()

# ---

# Server بسيط
def simple_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("localhost", 8080))
    server.listen(5)
    print("الخادم يعمل على المنفذ 8080...")
