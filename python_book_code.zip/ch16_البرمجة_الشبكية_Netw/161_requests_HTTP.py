# الفصل السادس عشر: البرمجة الشبكية (Networking)
# 16.1 requests (HTTP)
############################################################

# يتطلب: pip install requests
import requests

# ---

# GET request
response = requests.get("https://api.github.com")
print(response.status_code)
print(response.json())

# ---

# GET مع معاملات
params = {"q": "python", "page": 1}
response = requests.get("https://api.github.com/search/repositories", params=params)
data = response.json()
print(data["total_count"])

# ---

# POST request
payload = {"name": "test", "description": "وصف"}
response = requests.post("https://httpbin.org/post", json=payload)
print(response.json())

# ---

# مع Headers
headers = {"Authorization": "Bearer token123"}
response = requests.get("https://api.example.com/data", headers=headers)
