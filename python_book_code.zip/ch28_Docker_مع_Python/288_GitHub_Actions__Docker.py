# الفصل الثامن والعشرون: Docker مع Python
# 28.8 GitHub Actions + Docker
############################################################

# .github/workflows/docker.yml
name: Build and Push Docker

# ---

on:

# ---

jobs:
