# الفصل الثامن والعشرون: Docker مع Python
# 28.2 Dockerfile - ملف التعريف
############################################################

# Dockerfile
# === المرحلة 1: البناء ===
FROM python:3.11-slim as builder

# ---

WORKDIR /app

# ---

# تثبيت التبعيات
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# ---

# === المرحلة 2: الإنتاج ===
FROM python:3.11-slim

# ---

WORKDIR /app

# ---

# نسخ التبعيات من المرحلة الأولى
COPY --from=builder /root/.local /root/.local
ENV PATH=/root/.local/bin:$PATH

# ---

# نسخ الكود
COPY src/ ./src/

# ---

# متغيرات البيئة
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV PORT=8000

# ---

EXPOSE 8000

# ---

# المستخدم غير الجذري (أمان)
RUN useradd -m appuser
USER appuser

# ---

CMD ["python", "-m", "uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
