# الفصل الثامن والعشرون: Docker مع Python
# 28.6 نشر Python على السحابة
############################################################

# AWS ECS
# 1. دفع الصورة لـ ECR
aws ecr get-login-password | docker login --username AWS --password-stdin $ECR_URL
docker tag myapp:latest $ECR_URL/myapp:latest
docker push $ECR_URL/myapp:latest

# ---

# 2. ECS Task Definition
{

# ---

}

# ---

# Kubernetes (k8s)
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:

# ---

spec:

# ---

---
apiVersion: v1
kind: Service
metadata:

# ---

spec:
