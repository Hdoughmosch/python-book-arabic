# الفصل الثامن والعشرون: Docker مع Python
# 28.7 Docker مع Ollama (AI محلي)
############################################################

# docker-compose.yml for AI App
version: '3.8'

# ---

services:

# ---

volumes:
