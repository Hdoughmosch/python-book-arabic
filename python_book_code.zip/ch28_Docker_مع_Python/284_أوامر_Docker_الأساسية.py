# الفصل الثامن والعشرون: Docker مع Python
# 28.4 أوامر Docker الأساسية
############################################################

# بناء الصورة
docker build -t myapp:latest .

# ---

# تشغيل الحاوية
docker run -d -p 8000:8000 --name myapp myapp:latest

# ---

# Docker Compose
docker-compose up -d          # تشغيل في الخلفية
docker-compose up --build     # إعادة بناء
docker-compose down           # إيقاف وحذف
docker-compose logs -f        # متابعة السجلات
docker-compose exec app bash  # دخول للحاوية

# ---

# إدارة الصور
docker images
docker rmi myapp:latest
docker system prune -f        # تنظيف

# ---

# إدارة الحاويات
docker ps                     # نشطة
docker ps -a                  # الكل
docker stop myapp
docker rm myapp
docker logs -f myapp
