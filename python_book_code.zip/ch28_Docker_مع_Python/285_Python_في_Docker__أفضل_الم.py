# الفصل الثامن والعشرون: Docker مع Python
# 28.5 Python في Docker - أفضل الممارسات
############################################################

# 1. استخدام صور صغيرة
FROM python:3.11-alpine       # ~50 MB
# بدلاً من
FROM python:3.11              # ~900 MB

# ---

# 2. تجميع أوامر RUN
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# ---

# 3. .dockerignore
# .dockerignore
__pycache__
*.pyc
*.pyo
.git
.env
venv/
.pytest_cache/
*.md
tests/

# ---

# 4. Multi-stage builds
FROM python:3.11 as builder
RUN pip install --user -r requirements.txt

# ---

FROM python:3.11-slim
COPY --from=builder /root/.local /root/.local

# ---

# 5. Health Check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
