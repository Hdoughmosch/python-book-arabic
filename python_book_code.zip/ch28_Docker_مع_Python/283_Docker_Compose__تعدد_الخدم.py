# الفصل الثامن والعشرون: Docker مع Python
# 28.3 Docker Compose - تعدد الخدمات
############################################################

# docker-compose.yml
version: '3.8'

# ---

services:

# ---

volumes:
