# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.12 حل المشاكل الشائعة
############################################################

مشكلة 1: 'ModuleNotFoundError' عند التشغيل
-------------------------------------------
# السبب: PyInstaller لم يكتشف المكتبة
# الحل: استخدم --hidden-import

# ---

pyinstaller --onefile \
    --hidden-import 'numpy.core._dtype_ctypes' \
    --hidden-import 'scipy.spatial.transform._rotation_groups' \
    --hidden-import 'PIL._tkinter_finder' \
    app.py

# ---

# او في ملف .spec:
hiddenimports=[
    'numpy.core._dtype_ctypes',
    'scipy.spatial.transform._rotation_groups',
    'PIL._tkinter_finder',
]

# ---

مشكلة 2: ملفات البيانات غير موجودة
-------------------------------------
# السبب: المسار غير صحيح في الملف التنفيذي
# الحل: استخدم دالة resource_path()

# ---

import sys
import os

# ---

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath('.')
    return os.path.join(base_path, relative_path)

# ---

# استخدمها لكل الملفات:
config_path = resource_path('config.json')
image_path = resource_path('images/logo.png')
db_path = resource_path('data/database.db')

# ---

مشكلة 3: حجم الملف كبير جداً
-----------------------------
# الحلول:

# ---

# 1. استبعاد المكتبات غير المستخدمة
pyinstaller --onefile \
    --exclude-module 'matplotlib' \
    --exclude-module 'tkinter' \
    --exclude-module 'unittest' \
    --exclude-module 'pydoc' \
    app.py

# ---

# 2. استخدام UPX للضغط
# حمل UPX من https://upx.github.io/
pyinstaller --onefile --upx-dir /path/to/upx app.py

# ---

# 3. استخدام مجلد بدلاً من ملف واحد
pyinstaller app.py  # بدون --onefile

# ---

# 4. تحليل الحجم
pyi-archive_viewer dist/app.exe

# ---

مشكلة 4: بطء تشغيل الملف التنفيذي
-----------------------------------
# السبب: فك ضغط الملفات في الملف الواحد
# الحل: استخدم مجلد (بدون --onefile) او:

# ---

# في ملف .spec:
exe = EXE(
    ...
    noarchive=True,  # True = عدم ضغط Python files
    ...
)

# ---

مشكلة 5: مكافح الفيروسات يحذف الملف
--------------------------------------
# السبب: PyInstaller يستخدم bootloader مشهور
# الحلول:

# ---

# 1. استخدم --onefile (اقل احتمالاً للحذف)
# 2. قم بتوقيع الملف رقمياً (Windows)
# 3. ارفع الملف لفحص False Positive
# 4. استخدم Nuitka كبديل

# ---

# توقيع الملف على Windows:
signtool sign /f certificate.pfx /p password app.exe

# ---

مشكلة 6: الخطوط العربية لا تظهر
---------------------------------
# السبب: الخطوط غير مضمنة في الملف التنفيذي
# الحل:

# ---

# 1. تضمين ملفات الخطوط
pyinstaller --onefile \
    --add-data 'fonts/*.ttf;fonts' \
    app.py

# ---

# 2. في الكود:
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'DejaVu Sans'

# ---

# 3. لـ Tkinter:
import tkinter.font as tkfont
font = tkfont.Font(family='Arial', size=12)

# ---

مشكلة 7: قاعدة البيانات SQLite تفقد البيانات
-----------------------------------------------
# السبب: الملف التنفيذي يستخرج في مجلد مؤقت
# الحل: حفظ قاعدة البيانات في مجلد المستخدم

# ---

import os
import sys

# ---

def get_db_path():
    # مجلد بيانات التطبيق
    if sys.platform == 'win32':
        app_data = os.environ.get('APPDATA')
    elif sys.platform == 'darwin':
        app_data = os.path.expanduser('~/Library/Application Support')
    else:
        app_data = os.path.expanduser('~/.local/share')

# ---

# الاستخدام
db_path = get_db_path()
conn = sqlite3.connect(db_path)
