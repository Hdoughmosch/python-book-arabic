# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.8 مثال 2: تطبيق Tkinter مع موارد
############################################################

# gui_app.py
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import json
import sys
import os

# ---

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# ---

class App:
    def __init__(self, root):
        self.root = root
        self.root.title('تطبيقي')
        self.root.geometry('400x500')

# ---

if __name__ == '__main__':
    root = tk.Tk()
    app = App(root)
    root.mainloop()

# ---

# البناء
pyinstaller --onefile --noconsole \
    --add-data 'images;images' \
    --add-data 'config.json;.' \
    --icon=images/icon.ico \
    --name 'تطبيقي' \
    gui_app.py
