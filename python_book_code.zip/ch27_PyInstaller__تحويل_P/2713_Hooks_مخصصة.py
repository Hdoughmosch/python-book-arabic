# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.13 Hooks مخصصة
############################################################

# Hooks هي ملفات Python تساعد PyInstaller في اكتشاف التبعيات
# انشاء مجلد hooks في مشروعك

# ---

# hooks/hook-mymodule.py
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# ---

# جمع كل ملفات البيانات
datas = collect_data_files('mymodule')

# ---

# جمع كل الـ submodules
hiddenimports = collect_submodules('mymodule')

# ---

# استخدام الـ Hook
pyinstaller --onefile \
    --additional-hooks-dir=hooks \
    app.py

# ---

# مثال hook لـ TensorFlow
# hooks/hook-tensorflow.py
from PyInstaller.utils.hooks import collect_all

# ---

datas, binaries, hiddenimports = collect_all('tensorflow')
