# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.1 ما هو PyInstaller؟
############################################################

pip install pyinstaller

# ---

# للتحديث
pip install --upgrade pyinstaller

# ---

# التحقق من الاصدار
pyinstaller --version
