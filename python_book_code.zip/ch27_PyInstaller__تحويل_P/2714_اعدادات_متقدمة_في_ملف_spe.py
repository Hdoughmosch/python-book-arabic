# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.14 اعدادات متقدمة في ملف .spec
############################################################

# تحليل متقدم
a = Analysis(
    ['main.py'],
    pathex=['/path/to/modules'],  # مسارات اضافية
    binaries=[                     # ملفات DLL/so/dylib
        ('/path/to/lib.dll', '.'),
    ],
    datas=[                        # ملفات بيانات
        ('config.json', '.'),
        ('images/*.png', 'images'),
        ('data', 'data'),          # مجلد كامل
    ],
    hiddenimports=[
        'pkg_resources',
        'sklearn.utils._typedefs',
    ],
    hookspath=['./hooks'],         # مسارات hooks
    hooksconfig={                  # اعدادات hooks
        'gi': {
            'languages': ['en'],
        }
    },
    runtime_hooks=['./runtime_hook.py'],
    excludes=[                     # استبعاد
        'matplotlib',
        'tkinter',
        'unittest',
        'pydoc',
        'email',
        'http',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# ---

# runtime_hook.py - يتنفذ قبل الكود الرئيسي
import sys
import os

# ---

# اضافة مسارات
if hasattr(sys, '_MEIPASS'):
    # نحن في الملف التنفيذي
    base_path = sys._MEIPASS
else:
    base_path = os.path.abspath('.')

# ---

sys.path.insert(0, os.path.join(base_path, 'lib'))
