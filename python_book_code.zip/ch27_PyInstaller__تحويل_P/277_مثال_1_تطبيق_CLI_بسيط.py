# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.7 مثال 1: تطبيق CLI بسيط
############################################################

# calculator.py
import argparse

# ---

def main():
    parser = argparse.ArgumentParser(description='الة حاسبة')
    parser.add_argument('a', type=float, help='الرقم الاول')
    parser.add_argument('b', type=float, help='الرقم الثاني')
    parser.add_argument('--op', default='+', choices=['+', '-', '*', '/'],
                      help='العملية')

# ---

if __name__ == '__main__':
    main()

# ---

# البناء
pyinstaller --onefile calculator.py

# ---

# الاستخدام
calculator.exe 10 5 --op +
calculator.exe 10 5 --op /
