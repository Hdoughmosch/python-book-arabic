# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.6 الوصول الى ملفات البيانات في الملف التنفيذي
############################################################

# مشكلة: المسار يختلف بين التشغيل العادي والملف التنفيذي
# الحل: استخدام sys._MEIPASS

# ---

import sys
import os

# ---

def resource_path(relative_path):
    """الحصول على المسار الصحيح للموارد"""
    try:
        # PyInstaller ينشئ مجلد مؤقت
        base_path = sys._MEIPASS
    except AttributeError:
        # التشغيل العادي
        base_path = os.path.abspath(".")

# ---

# الاستخدام
icon_path = resource_path('images/icon.png')
config_path = resource_path('config.json')
db_path = resource_path('data/database.db')

# ---

# مثال قراءة ملف
with open(resource_path('config.json'), 'r', encoding='utf-8') as f:
    config = json.load(f)

# ---

# مثال تحميل صورة في Tkinter
from PIL import Image, ImageTk
img = Image.open(resource_path('images/logo.png'))
photo = ImageTk.PhotoImage(img)

# ---

# مثال تحميل قاعدة بيانات SQLite
import sqlite3
conn = sqlite3.connect(resource_path('data/app.db'))
