# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.4 الخيارات المتقدمة
############################################################

# اضافة ملفات بيانات (--add-data)
# الصيغة: 'source;destination' على Windows
# الصيغة: 'source:destination' على Linux/macOS
pyinstaller --onefile \
    --add-data 'config.json;.' \
    --add-data 'images/*.png;images' \
    --add-data 'data/*.csv;data' \
    app.py

# ---

# اخفاء الواجهة الرسومية (--hidden-import)
# لاستيراد مكتبات يفشل PyInstaller في اكتشافها
pyinstaller --onefile \
    --hidden-import 'pkg_resources' \
    --hidden-import 'sklearn.utils._typedefs' \
    --hidden-import 'pandas._libs.tslibs.np_datetime' \
    app.py

# ---

# استبعاد مكتبات (--exclude-module)
# لتقليل حجم الملف
pyinstaller --onefile \
    --exclude-module 'matplotlib' \
    --exclude-module 'tkinter' \
    app.py

# ---

# تحديد مسار العمل (--workpath, --distpath, --specpath)
pyinstaller --onefile \
    --workpath ./build_temp \
    --distpath ./output \
    --specpath ./specs \
    app.py

# ---

# ضغط الملفات بـ UPX (--upx-dir)
# يتطلب تثبيت UPX اولاً
pyinstaller --onefile --upx-dir /path/to/upx app.py

# ---

# تحديد اصدار Python (--python-option)
pyinstaller --python-option '-O' app.py  # تحسين
