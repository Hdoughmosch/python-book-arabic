# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.3 الخيارات الاساسية
############################################################

# ملف واحد (--onefile)
# يجمع كل شيء في ملف .exe واحد
pyinstaller --onefile hello.py

# ---

# بدون نافذة console (--noconsole / --windowed)
# للتطبيقات ذات الواجهة الرسومية
pyinstaller --onefile --noconsole gui_app.py

# ---

# تحديد اسم الملف (--name)
pyinstaller --onefile --name 'تطبيقي' hello.py

# ---

# ايقونة مخصصة (--icon)
# الايقونة يجب ان تكون .ico على Windows
pyinstaller --onefile --icon=app.ico hello.py

# ---

# تنظيف الملفات المؤقتة (--clean)
pyinstaller --onefile --clean hello.py

# ---

# الكتابة فوق الملفات الموجودة (--noconfirm)
pyinstaller --onefile --noconfirm hello.py
