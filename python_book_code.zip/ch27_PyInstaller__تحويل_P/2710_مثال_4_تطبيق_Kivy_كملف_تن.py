# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.10 مثال 4: تطبيق Kivy كملف تنفيذي
############################################################

# kivy_app.py
import os
import sys
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.config import Config

# ---

# منع تغيير حجم النافذة
Config.set('graphics', 'resizable', '0')
Window.size = (400, 600)

# ---

class KivyApp(App):
    def build(self):
        self.count = 0

# ---

if __name__ == '__main__':
    KivyApp().run()

# ---

# البناء
pyinstaller --onefile --noconsole \
    --hidden-import 'kivy' \
    --hidden-import 'kivy.core.window.window_sdl2' \
    --hidden-import 'kivy.graphics.buffer' \
    --add-data '*.kv;.' \
    --icon=app.ico \
    --name 'KivyCounter' \
    kivy_app.py
