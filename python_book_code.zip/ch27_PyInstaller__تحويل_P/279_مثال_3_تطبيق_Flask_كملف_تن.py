# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.9 مثال 3: تطبيق Flask كملف تنفيذي
############################################################

# web_app.py
from flask import Flask, render_template_string
import webbrowser
import threading
import os
import sys

# ---

app = Flask(__name__)

# ---

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html dir="rtl">
<head>
    <title>تطبيقي</title>
    <style>
        body { font-family: Arial; text-align: center; padding: 50px; }
        h1 { color: #306998; }
        .box { background: #f0f0f0; padding: 20px; border-radius: 10px; }
    </style>
</head>
<body>
    <h1>مرحباً بك في تطبيق Flask المدمج!</h1>
    <div class="box">
        <p>هذا تطبيق ويب يعمل من ملف تنفيذي</p>
        <p>الاصدار: 1.0</p>
    </div>
</body>
</html>
'''

# ---

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

# ---

def open_browser():
    webbrowser.open('http://127.0.0.1:5000/')

# ---

if __name__ == '__main__':
    # فتح المتصفح بعد ثانية
    threading.Timer(1.25, open_browser).start()
    print('التطبيق يعمل على http://127.0.0.1:5000/')
    print('اضغط Ctrl+C للخروج')
    app.run(debug=False)

# ---

# البناء
pyinstaller --onefile \
    --hidden-import 'jinja2.ext' \
    --hidden-import 'flask' \
    --name 'WebApp' \
    web_app.py
