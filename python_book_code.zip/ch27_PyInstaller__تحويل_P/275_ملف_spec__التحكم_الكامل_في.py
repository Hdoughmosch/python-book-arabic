# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.5 ملف .spec - التحكم الكامل في البناء
############################################################

# انشاء ملف spec
pyinstaller --onefile app.py
# ثم تعديل app.spec

# ---

# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.building.build_main import Analysis, PYZ, EXE, COLLECT, BUNDLE

# ---

block_cipher = None

# ---

a = Analysis(
    ['app.py'],                    # ملفات الدخول
    pathex=[],                      # مسارات اضافية
    binaries=[],                    # ملفات ثنائية
    datas=[
        ('config.json', '.'),       # (مصدر, وجهة)
        ('images', 'images'),       # مجلد كامل
        ('*.ttf', 'fonts'),         # wildcard
    ],
    hiddenimports=[
        'pkg_resources',
        'sklearn.utils._typedefs',
    ],
    hookspath=[],                   # مسارات hooks مخصصة
    hooksconfig={},                 # اعدادات hooks
    runtime_hooks=[],               # hooks وقت التشغيل
    excludes=[                      # استبعاد مكتبات
        'matplotlib',
        'tkinter',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,                # False = استخراج الملفات
)

# ---

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ---

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='تطبيقي',                 # اسم الملف التنفيذي
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                       # تفعيل UPX
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,                  # False = بدون console
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,         # هوية التوقيع (macOS)
    entitlements_file=None,         # ملف entitlements
    icon='app.ico',                 # الايقونة
)

# ---

# بناء باستخدام ملف spec
pyinstaller app.spec

# ---

# اعادة البناء فقط
pyinstaller --clean app.spec
