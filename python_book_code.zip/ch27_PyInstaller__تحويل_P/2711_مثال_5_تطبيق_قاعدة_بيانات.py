# الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
# 27.11 مثال 5: تطبيق قاعدة بيانات SQLite مع واجهة رسومية
############################################################

# db_app.py
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import os
import sys

# ---

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath('.')
    return os.path.join(base_path, relative_path)

# ---

class DatabaseApp:
    def __init__(self, root):
        self.root = root
        self.root.title('مدير الطلاب')
        self.root.geometry('500x400')

# ---

if __name__ == '__main__':
    root = tk.Tk()
    app = DatabaseApp(root)
    root.mainloop()

# ---

# البناء
pyinstaller --onefile --noconsole \
    --name 'StudentManager' \
    --icon=student.ico \
    db_app.py
