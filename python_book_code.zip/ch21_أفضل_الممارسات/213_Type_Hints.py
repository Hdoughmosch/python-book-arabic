# الفصل الحادي والعشرون: أفضل الممارسات
# 21.3 Type Hints
############################################################

from typing import List, Dict, Optional, Union

# ---

def greet(name: str, times: int = 1) -> str:
    """إرجاع رسالة ترحيب."""
    return (f"مرحباً {name}!\n") * times

# ---

def process_students(students: List[Dict[str, Union[str, int]]]) -> Optional[int]:
    """معالجة قائمة الطلاب وإرجاع العدد."""
    if not students:
        return None
    return len(students)

# ---

def find_student(students: List[dict], name: str) -> Optional[dict]:
    """البحث عن طالب بالاسم."""
    for student in students:
        if student.get("name") == name:
            return student
    return None
