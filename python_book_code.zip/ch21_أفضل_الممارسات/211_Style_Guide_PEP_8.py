# الفصل الحادي والعشرون: أفضل الممارسات
# 21.1 Style Guide (PEP 8)
############################################################

# ✅ صحيح
def calculate_area(width, height):
    """حساب مساحة المستطيل."""
    return width * height

# ---

class BankAccount:
    """يمثل حساباً مصرفياً."""

# ---

# ❌ خاطئ
def calc(w,h):
    return w*h

# ---

class bankaccount:
    def __init__(self,b=0):
        self.b=b
