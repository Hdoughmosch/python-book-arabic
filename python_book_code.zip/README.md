# Python Book Code Examples

## Structure

### الفصل الاول: مقدمة في Python
  - `12_تثبيت_Python.py` (3 lines)
  - `13_اول_برنامج_Python.py` (10 lines)

### الفصل الثاني: المتغيرات وانواع البيانات
  - `21_المتغيرات.py` (9 lines)
  - `22_انواع_البيانات_الاساسية.py` (15 lines)
  - `23_التحويل_بين_الانواع.py` (11 lines)

### الفصل الثالث: العمليات الحسابية والمنطقية
  - `31_العمليات_الحسابية.py` (18 lines)
  - `32_العمليات_المنطقية.py` (18 lines)

### الفصل الرابع: السلاسل النصية (Strings)
  - `41_انشاء_ومعالجة_النصوص.py` (14 lines)
  - `42_تقطيع_النصوص_Slicing.py` (11 lines)
  - `43_دوال_النصوص.py` (18 lines)
  - `44_تنسيق_النصوص.py` (12 lines)

### الفصل الخامس: القوائم (Lists)
  - `51_انشاء_والوصول_للقوائم.py` (12 lines)
  - `52_تقطيع_القوائم.py` (6 lines)
  - `53_دوال_وطرق_القوائم.py` (28 lines)
  - `54_فهم_القوائم_List_Comprehens.py` (14 lines)

### الفصل السادس: الصفوف (Tuples) والمجموعات (Sets)
  - `61_الصفوف_Tuples.py` (17 lines)
  - `62_المجموعات_Sets.py` (28 lines)

### الفصل السابع: القواميس (Dictionaries)
  - `71_انشاء_والوصول_للقواميس.py` (18 lines)
  - `72_طرق_القواميس.py` (20 lines)
  - `73_فهم_القواميس_Dictionary_Com.py` (7 lines)

### الفصل الثامن: جمل التحكم
  - `81_جملة_if.py` (23 lines)
  - `82_جملة_for.py` (25 lines)
  - `83_جملة_while.py` (24 lines)

### الفصل التاسع: الدوال (Functions)
  - `91_تعريف_واستدعاء_الدوال.py` (26 lines)
  - `92_انواع_المعاملات.py` (21 lines)
  - `93_دوال_Lambda.py` (21 lines)
  - `94_دوال_متقدمة.py` (28 lines)

### الفصل العاشر: البرمجة كائنية التوجه (OOP)
  - `101_Classes_و_Objects.py` (13 lines)
  - `102_الوراثة_Inheritance.py` (14 lines)
  - `103_Encapsulation_و_Polymorphi.py` (24 lines)
  - `104_Class_Methods_و_Static_Met.py` (11 lines)

### الفصل الحادي عشر: التعامل مع الملفات
  - `111_القراءة_والكتابة.py` (17 lines)
  - `112_التعامل_مع_CSV.py` (17 lines)
  - `113_التعامل_مع_JSON.py` (21 lines)

### الفصل الثاني عشر: معالجة الأخطاء
  - `121_tryexcept.py` (18 lines)
  - `122_tryexceptelsefinally.py` (16 lines)
  - `123_رفع_الاستثناءات.py` (26 lines)

### الفصل الثالث عشر: الوحدات والحزم (Modules & Packages)
  - `131_استيراد_الوحدات.py` (14 lines)
  - `132_انشاء_وحدة_خاصة.py` (19 lines)
  - `133_وحدة_os_و_sys.py` (18 lines)

### الفصل الرابع عشر: البرمجة المتقدمة
  - `141_Generators.py` (18 lines)
  - `142_Decorators_متقدمة.py` (31 lines)
  - `143_Context_Managers.py` (18 lines)

### الفصل الخامس عشر: مكتبات Python القياسية
  - `151_datetime.py` (19 lines)
  - `152_collections.py` (15 lines)
  - `153_itertools.py` (16 lines)

### الفصل السادس عشر: البرمجة الشبكية (Networking)
  - `161_requests_HTTP.py` (18 lines)
  - `162_socket.py` (16 lines)

### الفصل السابع عشر: قواعد البيانات (SQLite)
  - `171_SQLite_الاساسي.py` (35 lines)
  - `172_SQLite_مع_Context_Manager.py` (9 lines)

### الفصل الثامن عشر: تطوير الويب
  - `181_Flask__تطبيق_بسيط.py` (27 lines)
  - `182_FastAPI__تطبيق_حديث.py` (30 lines)

### الفصل التاسع عشر: علم البيانات الاساسي
  - `191_NumPy.py` (22 lines)
  - `192_Pandas.py` (27 lines)

### الفصل العشرون: مشاريع تطبيقية
  - `201_مدير_المهام_ToDo_List.py` (12 lines)
  - `202_آلة_حاسبة_متقدمة.py` (10 lines)
  - `203_تحميل_الملفات_مع_شريط_تقدم.py` (7 lines)

### الفصل الحادي والعشرون: أفضل الممارسات
  - `211_Style_Guide_PEP_8.py` (12 lines)
  - `212_Docstrings.py` (3 lines)
  - `213_Type_Hints.py` (15 lines)

### الفصل الثاني والعشرون: نصائح وأدوات
  - `221_Virtual_Environments.py` (12 lines)
  - `222_Testing.py` (17 lines)
  - `223_Logging.py` (17 lines)

### الفصل الثالث والعشرون: Async/Concurrency في Python
  - `232_المفاهيم_الأساسية.py` (24 lines)
  - `233_asyncio__المكتبة_الأساسية.py` (37 lines)
  - `234_aiohttp__طلبات_HTTP_غير_مت.py` (22 lines)
  - `235_aiomysql__aiopg__قواعد_الب.py` (20 lines)
  - `236_Threading__التعددية_بالخيو.py` (27 lines)
  - `237_Multiprocessing__التعددية_.py` (33 lines)
  - `238_مقارنة_Async_vs_Threading_.py` (15 lines)
  - `239_FastAPI_مع_Async.py` (13 lines)
  - `2310_WebSocket_غير_متزامن.py` (8 lines)
  - `2311_نصائح_وأفضل_الممارسات.py` (5 lines)

### الفصل الرابع والعشرون: اختبار متقدم (Advanced Testing)
  - `242_pytest__الإعداد_والأساسيات.py` (17 lines)
  - `243_Fixtures__التجهيزات_المتقد.py` (30 lines)
  - `244_Parametrization__الاختبار_.py` (17 lines)
  - `245_Mocking__المحاكاة.py` (24 lines)
  - `246_Async_Testing.py` (12 lines)
  - `247_Integration_Testing.py` (17 lines)
  - `248_PropertyBased_Testing_Hypo.py` (11 lines)
  - `249_Performance_Testing.py` (14 lines)
  - `2410_Coverage__تغطية_الاختبارا.py` (9 lines)
  - `2411_TDD__التطوير_الموجه_بالاخ.py` (24 lines)
  - `2412_CICD_مع_GitHub_Actions.py` (4 lines)
  - `2413_نصائح_وأفضل_الممارسات.py` (7 lines)

### الفصل الخامس والعشرون: تطوير تطبيقات الموبايل وسطح المكتب مع Kivy
  - `251_ما_هو_Kivy.py` (3 lines)
  - `252_أول_تطبيق_Kivy.py` (8 lines)
  - `253_التخطيطات_Layouts.py` (10 lines)
  - `254_أنواع_التخطيطات_المتاحة.py` (9 lines)
  - `255_التعامل_مع_المدخلات.py` (10 lines)
  - `256_الرسم_والرسوميات.py` (16 lines)
  - `257_ملفات_KV__فصل_التصميم_عن_ا.py` (20 lines)
  - `258_بناء_تطبيق_Android.py` (14 lines)
  - `259_تطبيق_كامل_مدير_المهام_Kiv.py` (22 lines)

### الفصل السادس والعشرون: BeeWare - Python اصلي على كل المنصات
  - `261_ما_هو_BeeWare.py` (1 lines)
  - `262_Toga__اطار_عمل_واجهة_المست.py` (14 lines)
  - `263_عناصر_واجهة_Toga.py` (33 lines)
  - `264_التخطيطات_في_Toga.py` (23 lines)
  - `265_الحوارات_والنوافذ_المنبثقة.py` (40 lines)
  - `266_انشاء_مشروع_BeeWare_كامل.py` (65 lines)
  - `267_اعدادات_pyprojecttoml.py` (36 lines)
  - `268_مقارنة_Kivy_و_BeeWare.py` (16 lines)
  - `269_نصائح_للانتاج.py` (10 lines)

### الفصل السابع والعشرون: PyInstaller - تحويل Python الى ملفات تنفيذية
  - `271_ما_هو_PyInstaller.py` (5 lines)
  - `272_الاستخدام_الاساسي.py` (13 lines)
  - `273_الخيارات_الاساسية.py` (15 lines)
  - `274_الخيارات_المتقدمة.py` (32 lines)
  - `275_ملف_spec__التحكم_الكامل_في.py` (57 lines)
  - `276_الوصول_الى_ملفات_البيانات_.py` (26 lines)
  - `277_مثال_1_تطبيق_CLI_بسيط.py` (15 lines)
  - `278_مثال_2_تطبيق_Tkinter_مع_مو.py` (29 lines)
  - `279_مثال_3_تطبيق_Flask_كملف_تن.py` (44 lines)
  - `2710_مثال_4_تطبيق_Kivy_كملف_تن.py` (26 lines)
  - `2711_مثال_5_تطبيق_قاعدة_بيانات.py` (26 lines)
  - `2712_حل_المشاكل_الشائعة.py` (99 lines)
  - `2713_Hooks_مخصصة.py` (16 lines)
  - `2714_اعدادات_متقدمة_في_ملف_spe.py` (46 lines)
  - `2715_نصائح_وافضل_الممارسات.py` (8 lines)
  - `2716_جدول_اوامر_PyInstaller_ال.py` (25 lines)

### الفصل الثامن والعشرون: Docker مع Python
  - `282_Dockerfile__ملف_التعريف.py` (24 lines)
  - `283_Docker_Compose__تعدد_الخدم.py` (4 lines)
  - `284_أوامر_Docker_الأساسية.py` (20 lines)
  - `285_Python_في_Docker__أفضل_الم.py` (27 lines)
  - `286_نشر_Python_على_السحابة.py` (19 lines)
  - `287_Docker_مع_Ollama_AI_محلي.py` (4 lines)
  - `288_GitHub_Actions__Docker.py` (4 lines)
  - `289_نصائح_وأفضل_الممارسات.py` (30 lines)

### الفصل التاسع والعشرون: الذكاء الاصطناعي المحلي مع Ollama
  - `291_ما_هو_Ollama.py` (8 lines)
  - `292_تثبيت_مكتبة_Python.py` (6 lines)
  - `293_سحب_النماذج_Pull_Models.py` (14 lines)
  - `294_الدردشة_الاساسية_Chat.py` (22 lines)
  - `295_التوليد_المتدفق_Streaming.py` (17 lines)
  - `296_تخصيص_معاملات_النموذج.py` (14 lines)
  - `297_النماذج_متعددة_الوسائط_Vis.py` (24 lines)
  - `298_التضمينات_Embeddings.py` (28 lines)
  - `299_استدعاء_الأدوات_Function_C.py` (67 lines)
  - `2910_إنشاء_نموذج_مخصص_Custom_M.py` (20 lines)
  - `2911_بناء_Chatbot_تفاعلي.py` (17 lines)
  - `2912_التوافق_مع_OpenAI_API.py` (32 lines)
  - `2913_مشروع_تطبيقي_مساعد_برمجي_.py` (43 lines)
  - `2914_مشروع_تطبيقي_RAG_بسيط_Ret.py` (32 lines)
  - `2915_إدارة_النماذج_والذاكرة.py` (14 lines)
  - `2916_نصائح_وأفضل_الممارسات.py` (16 lines)
