# الفصل التاسع: الدوال (Functions)
# 9.2 انواع المعاملات
############################################################

# معاملات افتراضية
def power(base, exponent=2):
    return base ** exponent

# ---

print(power(3))            # 9 (3²)
print(power(2, 3))         # 8 (2³)

# ---

# معاملات متغيرة الطول (*args)
def sum_all(*numbers):
    return sum(numbers)

# ---

print(sum_all(1, 2, 3, 4, 5))  # 15

# ---

# معاملات الكلمات المفتاحية (**kwargs)
def print_info(**kwargs):
    for key, value in kwargs.items():
        print(f"{key}: {value}")

# ---

print_info(name="أحمد", age=25, city="القاهرة")

# ---

# الجمع بين الانواع
def complex_function(a, b, *args, default="value", **kwargs):
    print(f"a={a}, b={b}")
    print(f"args={args}")
    print(f"default={default}")
    print(f"kwargs={kwargs}")

# ---

complex_function(1, 2, 3, 4, 5, default="custom", x=10, y=20)
