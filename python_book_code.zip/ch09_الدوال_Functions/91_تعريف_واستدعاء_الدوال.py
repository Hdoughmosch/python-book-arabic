# الفصل التاسع: الدوال (Functions)
# 9.1 تعريف واستدعاء الدوال
############################################################

# دالة بسيطة
def greet():
    print("مرحباً!")

# ---

greet()

# ---

# دالة مع معاملات
def greet_person(name):
    print(f"مرحباً {name}!")

# ---

greet_person("أحمد")

# ---

# دالة مع return
def add(a, b):
    return a + b

# ---

result = add(5, 3)
print(result)              # 8

# ---

# دالة متعددة المعاملات
def calculate(x, y, operation="+"):
    if operation == "+":
        return x + y
    elif operation == "-":
        return x - y
    elif operation == "*":
        return x * y
    elif operation == "/":
        return x / y if y != 0 else "خطأ: القسمة على صفر"

# ---

print(calculate(10, 5))        # 15 (افتراضي +)
print(calculate(10, 5, "-"))   # 5
print(calculate(10, 0, "/"))   # خطأ: القسمة على صفر
