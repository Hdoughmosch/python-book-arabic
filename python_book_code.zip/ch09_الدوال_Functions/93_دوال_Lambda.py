# الفصل التاسع: الدوال (Functions)
# 9.3 دوال Lambda
############################################################

# lambda بسيطة
square = lambda x: x ** 2
print(square(5))           # 25

# ---

# lambda متعددة المعاملات
multiply = lambda x, y: x * y
print(multiply(4, 5))      # 20

# ---

# استخدام lambda مع sorted()
students = [
    {"name": "أحمد", "grade": 85},
    {"name": "محمد", "grade": 92},
    {"name": "علي", "grade": 78}
]

# ---

sorted_students = sorted(students, key=lambda s: s["grade"], reverse=True)
print(sorted_students)

# ---

# استخدام lambda مع map()
numbers = [1, 2, 3, 4, 5]
squares = list(map(lambda x: x**2, numbers))
print(squares)             # [1, 4, 9, 16, 25]

# ---

# استخدام lambda مع filter()
evens = list(filter(lambda x: x % 2 == 0, numbers))
print(evens)               # [2, 4]
