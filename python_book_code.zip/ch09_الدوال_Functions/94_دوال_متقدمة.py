# الفصل التاسع: الدوال (Functions)
# 9.4 دوال متقدمة
############################################################

# دالة متداخلة (Nested)
def outer_function(x):
    def inner_function(y):
        return x + y
    return inner_function

# ---

add_five = outer_function(5)
print(add_five(10))        # 15

# ---

# Closure
def make_multiplier(n):
    def multiplier(x):
        return x * n
    return multiplier

# ---

double = make_multiplier(2)
triple = make_multiplier(3)
print(double(5))           # 10
print(triple(5))           # 15

# ---

# Decorator
def my_decorator(func):
    def wrapper(*args, **kwargs):
        print("قبل تنفيذ الدالة")
        result = func(*args, **kwargs)
        print("بعد تنفيذ الدالة")
        return result
    return wrapper

# ---

@my_decorator
def say_hello():
    print("مرحباً!")

# ---

say_hello()
