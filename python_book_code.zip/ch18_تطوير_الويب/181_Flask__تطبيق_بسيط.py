# الفصل الثامن عشر: تطوير الويب
# 18.1 Flask - تطبيق بسيط
############################################################

# يتطلب: pip install flask
from flask import Flask, jsonify, request

# ---

app = Flask(__name__)

# ---

# Route اساسي
@app.route("/")
def home():
    return "مرحباً بك في API!"

# ---

# Route مع متغير
@app.route("/hello/<name>")
def hello(name):
    return f"مرحباً {name}!"

# ---

# API JSON
@app.route("/api/students", methods=["GET"])
def get_students():
    students = [
        {"id": 1, "name": "أحمد", "grade": 85},
        {"id": 2, "name": "محمد", "grade": 92}
    ]
    return jsonify(students)

# ---

# POST request
@app.route("/api/students", methods=["POST"])
def add_student():
    data = request.get_json()
    # معالجة البيانات...
    return jsonify({"message": "تم الإضافة", "data": data}), 201

# ---

if __name__ == "__main__":
    app.run(debug=True)
