# الفصل الثامن عشر: تطوير الويب
# 18.2 FastAPI - تطبيق حديث
############################################################

# يتطلب: pip install fastapi uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

# ---

app = FastAPI(title="API الطلاب")

# ---

# نموذج البيانات
class Student(BaseModel):
    id: int
    name: str
    age: int
    grade: float

# ---

# قاعدة بيانات وهمية
students_db = [
    Student(id=1, name="أحمد", age=20, grade=85.5),
    Student(id=2, name="محمد", age=22, grade=92.0)
]

# ---

@app.get("/students", response_model=List[Student])
def get_students():
    return students_db

# ---

@app.get("/students/{student_id}")
def get_student(student_id: int):
    for student in students_db:
        if student.id == student_id:
            return student
    return {"error": "الطالب غير موجود"}

# ---

@app.post("/students", response_model=Student)
def create_student(student: Student):
    students_db.append(student)
    return student

# ---

# التشغيل: uvicorn filename:app --reload
