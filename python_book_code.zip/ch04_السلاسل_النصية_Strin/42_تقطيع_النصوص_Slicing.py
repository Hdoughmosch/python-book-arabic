# الفصل الرابع: السلاسل النصية (Strings)
# 4.2 تقطيع النصوص (Slicing)
############################################################

word = "Programming"

# ---

# من البداية الى الفهرس 4
print(word[:4])            # Prog

# ---

# من الفهرس 4 الى النهاية
print(word[4:])            # ramming

# ---

# من الفهرس 2 الى 6
print(word[2:6])           # ogra

# ---

# كل حرف ثاني
print(word[::2])           # Pormig

# ---

# عكس النص
print(word[::-1])          # gnimmargorP
