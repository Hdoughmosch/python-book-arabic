# الفصل الرابع: السلاسل النصية (Strings)
# 4.3 دوال النصوص
############################################################

text = "  Hello Python World  "

# ---

# ازالة المسافات
print(text.strip())        # "Hello Python World"

# ---

# التحويل لاحرف كبيرة
print(text.upper())        # "  HELLO PYTHON WORLD  "

# ---

# التحويل لاحرف صغيرة
print(text.lower())        # "  hello python world  "

# ---

# الاستبدال
print(text.replace("Python", "Java"))  # "  Hello Java World  "

# ---

# التقسيم
words = text.split()
print(words)               # ['Hello', 'Python', 'World']

# ---

# الدمج
new_text = "-".join(words)
print(new_text)            # Hello-Python-World

# ---

# البحث
print("Python" in text)    # True
print(text.find("Python")) # 8
